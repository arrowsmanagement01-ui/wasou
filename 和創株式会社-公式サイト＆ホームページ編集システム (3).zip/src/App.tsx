/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SiteProvider, useSiteData } from './context/SiteContext';
import { EditorToolbar } from './components/EditorToolbar';
import { EditorDrawer } from './components/EditorDrawer';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Concept } from './components/Concept';
import { WorksGallery } from './components/WorksGallery';
import { WorkDetailModal } from './components/WorkDetailModal';
import { Services } from './components/Services';
import { OnreiAirSystem } from './components/OnreiAirSystem';
import { LocalStrengthsAndVoice } from './components/LocalStrengthsAndVoice';
import { AeoSeoSimulator } from './components/AeoSeoSimulator';
import { CompanyProfile } from './components/CompanyProfile';
import { Faq } from './components/Faq';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

const MainLayout: React.FC = () => {
  const { viewportMode, selectedWorkForModal, setSelectedWorkForModal } = useSiteData();

  const handleConsultFromModal = (category: string) => {
    setSelectedWorkForModal(null);
    const contactEl = document.getElementById('contact');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        const select = document.getElementById('consultation-type') as HTMLSelectElement | null;
        if (select) {
          select.value = category;
        }
      }, 300);
    }
  };

  return (
    <div className="min-h-screen bg-[#121110] text-[#ece7df] flex flex-col items-center">
      <EditorToolbar />

      {/* Main responsive container based on viewport preview mode */}
      <div
        className={`w-full transition-all duration-300 relative ${
          viewportMode === 'tablet'
            ? 'max-w-[768px] my-6 shadow-2xl border-x-4 border-y-8 border-[#2e2a25] rounded-xl overflow-hidden'
            : viewportMode === 'mobile'
            ? 'max-w-[390px] my-6 shadow-2xl border-x-4 border-y-8 border-[#2e2a25] rounded-2xl overflow-hidden'
            : 'max-w-full'
        }`}
      >
        <Navbar />
        <main>
          <Hero />
          <Concept />
          <WorksGallery />
          <Services />
          <OnreiAirSystem />
          <LocalStrengthsAndVoice />
          <AeoSeoSimulator />
          <CompanyProfile />
          <Faq />
          <ContactSection />
        </main>
        <Footer />
      </div>

      {/* Modal for work specifications */}
      <WorkDetailModal
        work={selectedWorkForModal}
        onClose={() => setSelectedWorkForModal(null)}
        onConsult={handleConsultFromModal}
      />

      {/* Slide-over CMS Editor Drawer */}
      <EditorDrawer />
    </div>
  );
};

export default function App() {
  return (
    <SiteProvider>
      <MainLayout />
    </SiteProvider>
  );
}
