export interface CompanyInfo {
  name: string;
  legalName: string;
  representativeName: string;
  representativeTitle: string;
  foundedDate: string;
  postalCode: string;
  address: string;
  phone: string;
  email: string;
  openingHours: string;
  holidays: string;
  areaServed: string[];
}

export interface HeroData {
  badge: string;
  mainTitlePart1: string;
  mainTitlePart2: string;
  cityHighlight: string;
  subTitle: string;
  description: string;
  featurePills: string[];
  ctaPrimaryText: string;
  ctaSecondaryText: string;
  bgImageUrl: string;
}

export interface ConceptFeature {
  num: string;
  title: string;
  subtitle: string;
  description: string;
}

export interface ConceptData {
  sectionTag: string;
  mainTitle: string;
  subTitle: string;
  quoteTitle: string;
  quoteContent: string;
  bodyParagraph1: string;
  bodyParagraph2: string;
  features: ConceptFeature[];
  emblemTitle: string;
  emblemDescription: string;
  masterQuote: string;
  masterAuthor: string;
  imageUrl: string;
}

export type WorkCategory =
  | 'モダンBOX'
  | '洋風住宅'
  | '平屋'
  | 'ガルバリウム'
  | '和モダン'
  | 'リフォーム・再生'
  | '店舗および工場';

export interface WorkItem {
  id: string;
  title: string;
  category: WorkCategory;
  location: string;
  completionDate: string;
  floorArea?: string;
  structure?: string;
  insulation?: string;
  facadeSpec?: string;
  description: string;
  highlights: string[];
  imageUrl: string;
}

export interface ServiceItem {
  id: string;
  num: string;
  title: string;
  subtitle: string;
  description: string;
  features: string[];
  targetPersona: string;
  iconType: 'home' | 'wrench' | 'hammer' | 'building' | 'shield';
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
}

export interface LocalStrength {
  title: string;
  description: string;
  tag: string;
}

export interface LocalFocusData {
  badge: string;
  title: string;
  subtitle: string;
  lead: string;
  strengths: LocalStrength[];
  areasList: string[];
}

export interface SeoKeywordItem {
  id: string;
  keyword: string;
  volumeInfo: string;
  targetUser: string;
  articleTitle: string;
  aeoSnippet: string;
  qas: { question: string; answer: string }[];
}

export interface AeoSeoData {
  badge: string;
  title: string;
  subtitle: string;
  description: string;
  keywords: SeoKeywordItem[];
  pipelineSteps: {
    step: string;
    title: string;
    desc: string;
  }[];
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category?: string;
}

export interface ContactData {
  title: string;
  subtitle: string;
  phoneLead: string;
  promises: string[];
  successMessage: string;
}

export interface OnreiBenefit {
  id: string;
  num: string;
  title: string;
  subtitle: string;
  description: string;
  badge: string;
  iconName: string;
}

export interface OnreiSystemItem {
  id: string;
  name: string;
  englishName: string;
  tagline: string;
  description: string;
  features: string[];
  highlightTag: string;
  imageUrl?: string;
  logoSvg?: string;
}

export interface OnreiGalleryItem {
  id: string;
  imageUrl: string;
  title: string;
  caption: string;
  tag: string;
}

export interface OnreiSeasonalFeature {
  season: string;
  seasonLabel: string;
  title: string;
  description: string;
  meritPoints: string[];
}

export interface OnreiSystemData {
  badge: string;
  sectionTag: string;
  mainTitle: string;
  subTitle: string;
  partnerBadge: string;
  leadParagraph: string;
  companyIntro: string;
  officialUrl: string;
  heroImage: string;
  heroImageCaption: string;
  citationNotice: string;
  systems: OnreiSystemItem[];
  benefits: OnreiBenefit[];
  gallery: OnreiGalleryItem[];
  seasonalFeatures: OnreiSeasonalFeature[];
  craftsmanshipNote: string;
  warrantyInfo: string;
}

export interface SiteData {
  company: CompanyInfo;
  hero: HeroData;
  concept: ConceptData;
  works: WorkItem[];
  services: ServiceItem[];
  processSteps: ProcessStep[];
  localFocus: LocalFocusData;
  onreiSystem: OnreiSystemData;
  aeoSeo: AeoSeoData;
  faq: FaqItem[];
  contact: ContactData;
}

