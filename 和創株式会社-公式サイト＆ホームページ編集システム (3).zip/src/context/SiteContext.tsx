import React, { createContext, useContext, useState, useEffect } from 'react';
import { SiteData, WorkItem } from '../types/siteData';
import { initialSiteData } from '../data/defaultSiteData';

export type ViewportMode = 'desktop' | 'tablet' | 'mobile';

export type EditorTab =
  | 'company'
  | 'hero'
  | 'concept'
  | 'works'
  | 'services'
  | 'process'
  | 'local'
  | 'onrei'
  | 'aeoSeo'
  | 'faq'
  | 'contact';

interface SiteContextType {
  data: SiteData;
  updateData: (newData: Partial<SiteData>) => void;
  updateCompany: (company: Partial<SiteData['company']>) => void;
  updateHero: (hero: Partial<SiteData['hero']>) => void;
  updateConcept: (concept: Partial<SiteData['concept']>) => void;
  updateWork: (work: WorkItem) => void;
  addWork: (work: WorkItem) => void;
  deleteWork: (id: string) => void;
  updateServices: (services: SiteData['services']) => void;
  updateLocalFocus: (local: Partial<SiteData['localFocus']>) => void;
  updateOnreiSystem: (onrei: Partial<SiteData['onreiSystem']>) => void;
  updateAeoSeo: (aeoSeo: Partial<SiteData['aeoSeo']>) => void;
  updateFaq: (faq: SiteData['faq']) => void;
  updateContact: (contact: Partial<SiteData['contact']>) => void;
  resetToDefaults: () => void;
  exportJson: () => void;
  importJson: (jsonString: string) => boolean;
  isEditMode: boolean;
  setIsEditMode: (val: boolean) => void;
  isEditorDrawerOpen: boolean;
  setIsEditorDrawerOpen: (val: boolean) => void;
  activeEditorTab: EditorTab;
  setActiveEditorTab: (tab: EditorTab) => void;
  openEditorForSection: (tab: EditorTab) => void;
  viewportMode: ViewportMode;
  setViewportMode: (mode: ViewportMode) => void;
  selectedWorkForModal: WorkItem | null;
  setSelectedWorkForModal: (work: WorkItem | null) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const STORAGE_KEY = 'wasou_homepage_data_v7';

const SiteContext = createContext<SiteContextType | undefined>(undefined);

export const SiteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [data, setData] = useState<SiteData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // shallow merge with initialSiteData to handle any newly added fields
        return {
          ...initialSiteData,
          ...parsed,
          company: { ...initialSiteData.company, ...parsed.company },
          hero: { ...initialSiteData.hero, ...parsed.hero },
          concept: { ...initialSiteData.concept, ...parsed.concept },
          localFocus: { ...initialSiteData.localFocus, ...parsed.localFocus },
          onreiSystem: { ...initialSiteData.onreiSystem, ...parsed.onreiSystem },
          aeoSeo: { ...initialSiteData.aeoSeo, ...parsed.aeoSeo },
          contact: { ...initialSiteData.contact, ...parsed.contact },
        };
      }
    } catch (e) {
      console.error('Failed to load saved site data from localStorage:', e);
    }
    return initialSiteData;
  });

  const [isEditMode, setIsEditMode] = useState<boolean>(false);
  const [isEditorDrawerOpen, setIsEditorDrawerOpen] = useState<boolean>(false);
  const [activeEditorTab, setActiveEditorTab] = useState<EditorTab>('hero');
  const [viewportMode, setViewportMode] = useState<ViewportMode>('desktop');
  const [selectedWorkForModal, setSelectedWorkForModal] = useState<WorkItem | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Auto save to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }, [data]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3200);
  };

  const updateData = (newData: Partial<SiteData>) => {
    setData((prev) => ({ ...prev, ...newData }));
    showToast('変更を自動保存しました');
  };

  const updateCompany = (company: Partial<SiteData['company']>) => {
    setData((prev) => ({ ...prev, company: { ...prev.company, ...company } }));
    showToast('基本情報を更新しました');
  };

  const updateHero = (hero: Partial<SiteData['hero']>) => {
    setData((prev) => ({ ...prev, hero: { ...prev.hero, ...hero } }));
    showToast('メインビジュアルを更新しました');
  };

  const updateConcept = (concept: Partial<SiteData['concept']>) => {
    setData((prev) => ({ ...prev, concept: { ...prev.concept, ...concept } }));
    showToast('コンセプトを更新しました');
  };

  const updateWork = (work: WorkItem) => {
    setData((prev) => ({
      ...prev,
      works: prev.works.map((w) => (w.id === work.id ? work : w)),
    }));
    showToast('施工イメージを更新しました');
  };

  const addWork = (work: WorkItem) => {
    setData((prev) => ({
      ...prev,
      works: [work, ...prev.works],
    }));
    showToast('新規施工イメージを追加しました');
  };

  const deleteWork = (id: string) => {
    setData((prev) => ({
      ...prev,
      works: prev.works.filter((w) => w.id !== id),
    }));
    showToast('施工イメージを削除しました');
  };

  const updateServices = (services: SiteData['services']) => {
    setData((prev) => ({ ...prev, services }));
    showToast('サービスラインナップを更新しました');
  };

  const updateLocalFocus = (local: Partial<SiteData['localFocus']>) => {
    setData((prev) => ({ ...prev, localFocus: { ...prev.localFocus, ...local } }));
    showToast('地域密着・こだわりを更新しました');
  };

  const updateOnreiSystem = (onrei: Partial<SiteData['onreiSystem']>) => {
    setData((prev) => ({ ...prev, onreiSystem: { ...prev.onreiSystem, ...onrei } }));
    showToast('オンレイ全館空調システム設定を更新しました');
  };

  const updateAeoSeo = (aeoSeo: Partial<SiteData['aeoSeo']>) => {
    setData((prev) => ({ ...prev, aeoSeo: { ...prev.aeoSeo, ...aeoSeo } }));
    showToast('AI・SEO設定を更新しました');
  };

  const updateFaq = (faq: SiteData['faq']) => {
    setData((prev) => ({ ...prev, faq }));
    showToast('よくある質問を更新しました');
  };

  const updateContact = (contact: Partial<SiteData['contact']>) => {
    setData((prev) => ({ ...prev, contact: { ...prev.contact, ...contact } }));
    showToast('お問い合わせ情報を更新しました');
  };

  const resetToDefaults = () => {
    if (window.confirm('すべての変更を破棄して、初期ホームページの状態に戻しますか？')) {
      setData(initialSiteData);
      localStorage.removeItem(STORAGE_KEY);
      showToast('初期ホームページデータに復元しました');
    }
  };

  const exportJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(data, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `wasou-site-data-${new Date().toISOString().slice(0, 10)}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('サイトデータをJSON形式で書き出しました');
  };

  const importJson = (jsonString: string): boolean => {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.company || !parsed.hero) {
        throw new Error('無効なデータ形式です');
      }
      setData({
        ...initialSiteData,
        ...parsed,
      });
      showToast('JSONデータから正常に復元しました');
      return true;
    } catch (e) {
      alert('JSONファイルの読み込みに失敗しました。フォーマットを確認してください。');
      return false;
    }
  };

  const openEditorForSection = (tab: EditorTab) => {
    setActiveEditorTab(tab);
    setIsEditMode(true);
    setIsEditorDrawerOpen(true);
  };

  return (
    <SiteContext.Provider
      value={{
        data,
        updateData,
        updateCompany,
        updateHero,
        updateConcept,
        updateWork,
        addWork,
        deleteWork,
        updateServices,
        updateLocalFocus,
        updateOnreiSystem,
        updateAeoSeo,
        updateFaq,
        updateContact,
        resetToDefaults,
        exportJson,
        importJson,
        isEditMode,
        setIsEditMode,
        isEditorDrawerOpen,
        setIsEditorDrawerOpen,
        activeEditorTab,
        setActiveEditorTab,
        openEditorForSection,
        viewportMode,
        setViewportMode,
        selectedWorkForModal,
        setSelectedWorkForModal,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </SiteContext.Provider>
  );
};

export const useSiteData = () => {
  const context = useContext(SiteContext);
  if (!context) {
    throw new Error('useSiteData must be used within a SiteProvider');
  }
  return context;
};
