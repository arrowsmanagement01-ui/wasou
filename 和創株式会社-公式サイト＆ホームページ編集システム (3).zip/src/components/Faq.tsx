import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { ChevronDown, HelpCircle, Plus, Minus } from 'lucide-react';

export const Faq: React.FC = () => {
  const { data } = useSiteData();
  const { faq } = data;
  const [openId, setOpenId] = useState<string | null>(faq[0]?.id || null);

  const toggleItem = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <EditableWrapper tab="faq" label="よくある質問 (FAQ)" id="faq">
      <section className="py-20 lg:py-28 bg-[#161513] relative border-b border-[#2a2723]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2">
              FREQUENTLY ASKED QUESTIONS
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              よくある質問
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#a8a196] [text-wrap:balance]">
              <span className="inline-block">家づくりやリフォーム、</span>
              <span className="inline-block">修繕に関する疑問にお答えいたします。</span>
            </p>
          </div>

          {/* Accordion List */}
          <div className="space-y-4">
            {faq.map((item) => {
              const isOpen = openId === item.id;
              return (
                <div
                  key={item.id}
                  className="bg-[#1c1a17] border border-[#2e2a25] hover:border-[#b38d4f]/50 rounded-sm overflow-hidden transition-colors shadow-sm"
                >
                  <button
                    onClick={() => toggleItem(item.id)}
                    className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer focus:outline-none"
                    aria-expanded={isOpen}
                  >
                    <div className="flex items-start gap-3.5">
                      <span className="w-6 h-6 rounded-full bg-[#b38d4f]/20 text-[#b38d4f] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                        Q
                      </span>
                      <div>
                        {item.category && (
                          <span className="text-[10px] text-[#b38d4f] font-medium bg-[#b38d4f]/10 px-2 py-0.5 rounded mr-2 inline-block">
                            {item.category}
                          </span>
                        )}
                        <span className="font-serif-jp text-sm sm:text-base font-bold text-[#f5f2eb] [text-wrap:balance]">
                          {item.question}
                        </span>
                      </div>
                    </div>
                    <div className="shrink-0 text-[#b38d4f]">
                      {isOpen ? <Minus className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-6 sm:px-6 sm:pb-6 pt-2 border-t border-[#262420] bg-[#171614] animate-fadeIn">
                      <div className="flex items-start gap-3.5 text-xs sm:text-sm text-[#dcd6cd] leading-relaxed">
                        <span className="w-6 h-6 rounded-full bg-[#38342f] text-[#f5f2eb] font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                          A
                        </span>
                        <p className="[text-wrap:pretty]">{item.answer}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
