import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Clock, Hammer, Mountain, ShieldCheck } from 'lucide-react';

export const LocalStrengthsAndVoice: React.FC = () => {
  const { data } = useSiteData();
  const { localFocus } = data;

  const renderIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <Clock className="w-6 h-6 text-[#b38d4f]" />;
      case 1:
        return <Hammer className="w-6 h-6 text-[#b38d4f]" />;
      case 2:
      default:
        return <Mountain className="w-6 h-6 text-[#b38d4f]" />;
    }
  };

  return (
    <EditableWrapper tab="local" label="地域密着・こだわり" id="local">
      <section className="py-20 lg:py-28 bg-[#121110] relative border-b border-[#2a2723]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2 [text-wrap:balance]">
              <span className="inline-block">魚津に根ざし、</span>
              <span className="inline-block">三代に寄り添う。</span>
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              <span className="inline-block">地域密着工務店としての誇り。</span>
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#dcd6cd] max-w-xl mx-auto leading-relaxed [text-wrap:pretty]">
              <span className="inline-block">大手ハウスメーカーでは手の届かない、</span>
              <span className="inline-block">現場とお客様との「距離の近さ」。</span>
              <br className="hidden sm:inline" />
              <span className="inline-block mt-1 sm:mt-0">家を建てた後から始まる、</span>
              <span className="inline-block">一生涯のお付き合いをお約束します。</span>
            </p>
          </div>

          {/* 3 Local Strengths */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 mb-16">
            {localFocus.strengths.map((st, idx) => (
              <div
                key={idx}
                className="bg-[#181715] border border-[#2e2a25] hover:border-[#b38d4f]/60 rounded-sm p-6 sm:p-8 transition-all duration-300 shadow-md relative group"
              >
                <div className="w-12 h-12 rounded-sm bg-[#23211d] border border-[#38342f] flex items-center justify-center mb-6 group-hover:border-[#b38d4f] transition-colors">
                  {renderIcon(idx)}
                </div>
                <span className="inline-block text-[10px] font-bold tracking-wider text-[#b38d4f] bg-[#b38d4f]/10 px-2 py-0.5 rounded mb-3">
                  {st.tag}
                </span>
                <h3 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] mb-3 [text-wrap:balance]">
                  {st.title}
                </h3>
                <p className="text-xs sm:text-sm text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                  {st.description}
                </p>
              </div>
            ))}
          </div>

          {/* Areas Served Bar */}
          <div className="bg-[#1a1815] border border-[#38342f] rounded-sm p-6 sm:p-8 text-center">
            <div className="flex items-center justify-center gap-2 mb-3">
              <ShieldCheck className="w-4 h-4 text-[#b38d4f] shrink-0" />
              <h4 className="font-serif-jp text-sm sm:text-base font-bold text-[#f5f2eb] [text-wrap:balance]">
                <span className="inline-block">富山県魚津市を中心に、</span>
                <span className="inline-block">北陸一円へ迅速に対応</span>
              </h4>
            </div>
            <p className="text-xs text-[#a8a196] mb-4 [text-wrap:pretty]">
              <span className="inline-block">現場への近さとフットワークを重視し、</span>
              <span className="inline-block">万全のアフターサポートをお約束します。</span>
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {localFocus.areasList.map((area, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1 rounded bg-[#23211d] border border-[#38342f] text-xs text-[#dcd6cd] hover:border-[#b38d4f] transition-colors"
                >
                  {area}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
