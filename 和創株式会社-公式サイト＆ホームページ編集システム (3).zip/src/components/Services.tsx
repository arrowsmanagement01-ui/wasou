import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Home, Wrench, Hammer, Building2, Shield, Check, ChevronRight } from 'lucide-react';

export const Services: React.FC = () => {
  const { data } = useSiteData();
  const { services, processSteps } = data;

  const renderIcon = (type: string) => {
    switch (type) {
      case 'home':
        return <Home className="w-6 h-6 text-[#b38d4f]" />;
      case 'wrench':
        return <Wrench className="w-6 h-6 text-[#b38d4f]" />;
      case 'hammer':
        return <Hammer className="w-6 h-6 text-[#b38d4f]" />;
      case 'building':
        return <Building2 className="w-6 h-6 text-[#b38d4f]" />;
      case 'shield':
      default:
        return <Shield className="w-6 h-6 text-[#b38d4f]" />;
    }
  };

  const scrollToContact = (serviceTitle: string) => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' });
      // preselect service type if input exists
      const selectEl = document.getElementById('consultation-type') as HTMLSelectElement | null;
      if (selectEl) {
        selectEl.value = serviceTitle;
      }
    }
  };

  return (
    <EditableWrapper tab="services" label="サービス一覧・工程" id="services">
      <section className="py-20 lg:py-28 bg-[#161513] relative border-b border-[#2a2723]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Heading */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2">
              SERVICES & BUSINESS
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              <span className="inline-block">和創の営業ラインナップ</span>
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#a8a196] [text-wrap:balance]">
              <span className="inline-block">新築の注文建築から小さな修繕まで。</span>
              <span className="inline-block">建物の規模を問わず、同じ熱量と誠実さで向き合います。</span>
            </p>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
            {services.map((srv, idx) => (
              <div
                key={srv.id}
                className={`bg-[#1c1a17] border border-[#2e2a25] hover:border-[#b38d4f]/60 rounded-sm p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 shadow-md group ${
                  idx === 0 || idx === 3 ? 'lg:col-span-1' : ''
                }`}
              >
                <div>
                  {/* Top Row: Number & Icon */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="font-serif-jp text-2xl font-bold text-[#b38d4f]/70">
                      {srv.num}
                    </span>
                    <div className="w-12 h-12 rounded-sm bg-[#23211d] border border-[#38342f] flex items-center justify-center group-hover:border-[#b38d4f]/60 transition-colors">
                      {renderIcon(srv.iconType)}
                    </div>
                  </div>

                  {/* Title & Subtitle */}
                  <h3 className="font-serif-jp text-xl font-bold text-[#f5f2eb] mb-2 [text-wrap:balance]">
                    {srv.title}
                  </h3>
                  <p className="text-xs text-[#b38d4f] font-medium mb-4 leading-relaxed [text-wrap:pretty]">
                    {srv.subtitle}
                  </p>
                  <p className="text-xs sm:text-sm text-[#a8a196] leading-relaxed mb-6 [text-wrap:pretty]">
                    {srv.description}
                  </p>

                  {/* Bullet Points */}
                  <ul className="space-y-2 mb-6">
                    {srv.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2 text-xs text-[#dcd6cd] [text-wrap:pretty]">
                        <Check className="w-3.5 h-3.5 text-[#b38d4f] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Target Persona */}
                  <div className="bg-[#181715] border border-[#282622] rounded p-3 text-[11px] text-[#a8a196] mb-6">
                    <span className="text-[#e6dfd5] font-semibold block mb-1">
                      こんな方におすすめ：
                    </span>
                    <span className="[text-wrap:pretty] block">{srv.targetPersona}</span>
                  </div>
                </div>

                {/* Consultation CTA button */}
                <button
                  onClick={() => scrollToContact(srv.title)}
                  className="w-full py-2.5 px-4 rounded-sm bg-[#23211d] hover:bg-[#b38d4f] text-[#e6dfd5] hover:text-[#121110] border border-[#38342f] hover:border-[#b38d4f] text-xs font-bold tracking-wider transition-all duration-200 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <span>「{srv.title}」について相談・見積依頼</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

          {/* 5-Step Process Flow (ご相談からお引渡し・アフターケアの流れ) */}
          <div className="bg-[#1a1815] border border-[#38342f] rounded-sm p-6 sm:p-10 relative overflow-hidden">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-[#b38d4f] font-serif-jp text-xs tracking-widest uppercase block mb-1">
                PROCESS & FLOW
              </span>
              <h3 className="font-serif-jp text-xl sm:text-3xl font-bold text-[#f5f2eb] [text-wrap:balance]">
                <span className="inline-block">ご相談からお引渡し・</span>
                <span className="inline-block">アフターケアの流れ</span>
              </h3>
              <p className="text-xs text-[#a8a196] mt-2 [text-wrap:balance]">
                <span className="inline-block">専任棟梁が最初から最後まで</span>
                <span className="inline-block">一貫して寄り添います</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
              {processSteps.map((step, sIdx) => (
                <div
                  key={step.step}
                  className="bg-[#141311] border border-[#2e2a25] p-5 rounded-sm relative flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-[#b38d4f]/20 text-[#b38d4f]">
                        STEP {step.step}
                      </span>
                    </div>
                    <h4 className="font-serif-jp text-sm sm:text-base font-bold text-[#f5f2eb] mb-2">
                      {step.title}
                    </h4>
                    <p className="text-xs text-[#a8a196] leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
