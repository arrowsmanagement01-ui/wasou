import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { ChevronRight, ArrowDown, Award, Sparkles, MapPin } from 'lucide-react';

export const Hero: React.FC = () => {
  const { data } = useSiteData();
  const { hero } = data;

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <EditableWrapper tab="hero" label="メインビジュアル" id="hero">
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden border-b border-[#2e2a24]">
        {/* Background Image with Dark Vignette and Lattice Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src={hero.bgImageUrl || '/assets/hero.jpg'}
            alt="和創株式会社 自由設計の注文邸宅"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-[0.42] contrast-[1.1] scale-[1.02] transform transition-transform duration-1000"
          />
          {/* Subtle grid pattern overlay */}
          <div className="absolute inset-0 koshi-pattern opacity-40"></div>
          {/* Radial Gradient Vignette */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#121110] via-transparent to-[#121110]/80"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-[#121110]/90 via-[#121110]/50 to-transparent"></div>

          {/* Image Annotation Badge */}
          <div className="absolute bottom-4 right-4 z-10 pointer-events-none select-none">
            <span className="px-2.5 py-1 rounded bg-[#121110]/80 border border-[#3e3932] text-[10px] text-[#a8a196] font-medium tracking-wider backdrop-blur-sm">
              ※イメージ画像
            </span>
          </div>
        </div>

        {/* Vertical Japanese Accent (Right Side) */}
        <div className="hidden lg:flex flex-col items-center absolute right-12 top-1/2 -translate-y-1/2 z-10 pointer-events-none select-none opacity-40">
          <div className="w-[1px] h-20 bg-gradient-to-b from-transparent to-[#b38d4f]"></div>
          <span className="vertical-text font-serif-jp text-sm tracking-[0.45em] text-[#e6dfd5] py-4">
            富山魚津·自由設計建築
          </span>
          <div className="w-[1px] h-20 bg-gradient-to-b from-[#b38d4f] to-transparent"></div>
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28 w-full">
          <div className="max-w-3xl">
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#1e1c19]/90 border border-[#b38d4f]/40 backdrop-blur-md mb-6 shadow-lg max-w-full">
              <span className="w-2 h-2 rounded-full bg-[#b38d4f] animate-ping shrink-0"></span>
              <span className="text-xs sm:text-sm text-[#e6dfd5] font-medium tracking-widest [text-wrap:balance]">
                {hero.badge === '富山県魚津市 · 理想のカタチを創る自由設計注文建築' ? (
                  <>
                    <span className="inline-block">富山県魚津市</span>
                    <span className="mx-1.5 opacity-60">·</span>
                    <span className="inline-block">理想のカタチを創る</span>
                    <span className="inline-block">自由設計注文建築</span>
                  </>
                ) : (
                  hero.badge
                )}
              </span>
            </div>

            {/* Main Headline */}
            <h1 className="font-serif-jp text-3xl sm:text-5xl lg:text-6xl font-bold text-[#f5f2eb] leading-[1.3] sm:leading-[1.22] tracking-wide mb-6 [text-wrap:balance]">
              <span className="inline-block">{hero.mainTitlePart1}</span>
              <span className="block mt-2 sm:mt-3">
                <span className="text-[#b38d4f] border-b-2 border-[#b38d4f]/60 pb-0.5 inline-block mr-1">
                  {hero.cityHighlight}
                </span>
                <span className="inline-block">{hero.mainTitlePart2}</span>
              </span>
            </h1>

            {/* Subtitle & Lead Paragraph */}
            <p className="text-base sm:text-lg text-[#dcd6cd] font-light leading-relaxed mb-4 max-w-2xl [text-wrap:pretty]">
              {hero.subTitle === 'モダンBOXタイプから洋風、開放的な平屋、洗練された和モダンまで。' ? (
                <>
                  <span className="inline-block">モダンBOXタイプから洋風、</span>
                  <span className="inline-block">開放的な平屋、</span>
                  <span className="inline-block">洗練された和モダンまで。</span>
                </>
              ) : (
                hero.subTitle
              )}
            </p>
            <p className="text-sm sm:text-base text-[#a8a196] leading-relaxed mb-8 max-w-2xl [text-wrap:pretty]">
              {hero.description === '雪国・富山の気候風土に耐え抜く堅牢な構造と、洗練された空間デザインを専任棟梁の確かな技術でお届けします。自由設計の注文建築から、リフォーム、店舗・工場、修繕まで地域密着で誠実にお応えします。' ? (
                <>
                  <span className="inline-block">雪国・富山の気候風土に耐え抜く堅牢な構造と、</span>
                  <span className="inline-block">洗練された空間デザインを</span>
                  <span className="inline-block">専任棟梁の確かな技術でお届けします。</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block mt-1 sm:mt-0">自由設計の注文建築から、</span>
                  <span className="inline-block">リフォーム、店舗・工場、修繕まで</span>
                  <span className="inline-block">地域密着で誠実にお応えします。</span>
                </>
              ) : (
                hero.description
              )}
            </p>

            {/* Feature Pills */}
            <div className="flex flex-wrap gap-2.5 sm:gap-3 mb-10">
              {hero.featurePills.map((pill, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-sm bg-[#1c1a17]/90 border border-[#3e3932] text-xs sm:text-sm text-[#e6dfd5] shadow-sm backdrop-blur-sm whitespace-nowrap"
                >
                  {idx === 0 && <Award className="w-3.5 h-3.5 text-[#b38d4f] shrink-0" />}
                  {idx === 1 && <Sparkles className="w-3.5 h-3.5 text-[#b38d4f] shrink-0" />}
                  {idx === 2 && <MapPin className="w-3.5 h-3.5 text-[#b38d4f] shrink-0" />}
                  <span>{pill}</span>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
              <button
                onClick={() => scrollToSection('contact')}
                className="px-8 py-4 rounded-sm bg-gradient-to-r from-[#b38d4f] via-[#c29853] to-[#8f6f3b] hover:from-[#c59b57] hover:to-[#9f7d43] text-[#121110] font-bold text-sm sm:text-base tracking-wider shadow-xl hover:shadow-2xl transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 group"
              >
                <span>{hero.ctaPrimaryText}</span>
                <ChevronRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
              </button>

              <button
                onClick={() => scrollToSection('works')}
                className="px-8 py-4 rounded-sm bg-[#1e1c19]/80 hover:bg-[#2b2722] border border-[#b38d4f]/60 hover:border-[#b38d4f] text-[#f5f2eb] font-medium text-sm sm:text-base tracking-wider transition-all duration-200 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{hero.ctaSecondaryText}</span>
                <ArrowDown className="w-4 h-4 text-[#b38d4f]" />
              </button>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 opacity-70 hover:opacity-100 transition-opacity">
          <span className="text-[10px] tracking-widest text-[#a8a196] uppercase font-mono">SCROLL</span>
          <div className="w-4 h-7 rounded-full border border-[#a8a196] flex items-start justify-center p-1">
            <div className="w-1 h-2 bg-[#b38d4f] rounded-full animate-bounce"></div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
