import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { ArrowUp, Phone, Mail, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  const { data } = useSiteData();
  const { company } = data;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0e0d0c] border-t border-[#23201c] text-[#a8a196] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 mb-12">
          {/* Brand Info */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#1c1a17] border border-[#b38d4f]/60 p-1 flex items-center justify-center">
                <img
                  src="/wasou-logo.svg"
                  alt={company.name}
                  className="w-full h-full object-contain invert-[0.9] sepia-[0.3]"
                />
              </div>
              <span className="font-serif-jp text-xl font-bold tracking-widest text-[#f5f2eb]">
                {company.name}
              </span>
            </div>
            <p className="text-xs text-[#8a8377] leading-relaxed max-w-sm [text-wrap:pretty]">
              <span className="inline-block">モダンBOX・洋風・平屋・和モダンまで、</span>
              <span className="inline-block">理想を形にする自由設計工務店。</span>
              <br className="hidden sm:inline" />
              <span className="inline-block mt-0.5 sm:mt-0">富山県魚津市を拠点に、</span>
              <span className="inline-block">新築注文住宅・リフォーム・リノベーション・店舗工場設計を手がけます。</span>
            </p>
            <div className="space-y-1.5 text-xs text-[#c5bcad] pt-2">
              <p className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#b38d4f]" />
                <span>富山県魚津市（富山県内全域対応）</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-[#b38d4f]" />
                <a href={`tel:${company.phone}`} className="hover:text-[#b38d4f]">
                  {company.phone} ({company.openingHours})
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#b38d4f]" />
                <a href={`mailto:${company.email}`} className="hover:text-[#b38d4f]">
                  {company.email}
                </a>
              </p>
            </div>
          </div>

          {/* Quick Sitemap */}
          <div className="lg:col-span-4">
            <h4 className="font-serif-jp text-sm font-bold text-[#f5f2eb] mb-4 tracking-wider">
              サイトマップ
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a href="#concept" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・デザインコンセプト
              </a>
              <a href="#works" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・施工イメージ
              </a>
              <a href="#services" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・営業ラインナップ
              </a>
              <a href="#onrei" className="hover:text-[#b38d4f] py-1 transition-colors text-[#b38d4f]">
                ・オンレイ全館空調
              </a>
              <a href="#local" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・地域密着・こだわり
              </a>
              <a href="#ai-seo" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・AI・自動SEO/AEO設計
              </a>
              <a href="#company" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・会社概要・代表挨拶
              </a>
              <a href="#faq" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・よくある質問 (FAQ)
              </a>
              <a href="#contact" className="hover:text-[#b38d4f] py-1 transition-colors">
                ・無料相談・お見積り
              </a>
            </div>
          </div>

          {/* Services List */}
          <div className="lg:col-span-3">
            <h4 className="font-serif-jp text-sm font-bold text-[#f5f2eb] mb-4 tracking-wider">
              建築サービス一覧
            </h4>
            <ul className="space-y-1.5 text-xs">
              <li>・注文建築（モダンBOX・洋風・平屋・和モダン）</li>
              <li>・オンレイ次世代全館空調「CLEnAIR」施工</li>
              <li>・リフォーム（水まわり刷新・高断熱窓改修）</li>
              <li>・リノベーション（古民家再生・耐震改修）</li>
              <li>・店舗および工場（商業店舗・工場施設）</li>
              <li>・修繕（雨漏り・建具調整・瓦補修）</li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar with Copyright & Back to Top */}
        <div className="pt-8 border-t border-[#1f1d19] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#6e685f]">
          <p>© {new Date().getFullYear()} {company.name} ({company.legalName}). All rights reserved.</p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 text-xs text-[#a8a196] hover:text-[#b38d4f] transition-colors cursor-pointer py-1 px-3 rounded bg-[#171614] border border-[#2a2723]"
          >
            <span>ページトップへ戻る</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};
