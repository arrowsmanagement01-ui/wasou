import React, { useRef } from 'react';
import { useSiteData, ViewportMode, EditorTab } from '../context/SiteContext';
import {
  Edit3,
  Eye,
  Sliders,
  RotateCcw,
  Download,
  Upload,
  Laptop,
  Tablet,
  Smartphone,
  CheckCircle,
} from 'lucide-react';

export const EditorToolbar: React.FC = () => {
  const {
    isEditMode,
    setIsEditMode,
    isEditorDrawerOpen,
    setIsEditorDrawerOpen,
    openEditorForSection,
    viewportMode,
    setViewportMode,
    resetToDefaults,
    exportJson,
    importJson,
    toastMessage,
  } = useSiteData();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        if (text) {
          importJson(text);
        }
      };
      reader.readAsText(file);
    }
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <>
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-lg bg-[#1f1d19] border border-[#b38d4f] text-[#f5f2eb] shadow-2xl text-sm font-medium animate-bounce">
          <CheckCircle className="w-4 h-4 text-[#b38d4f]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Editor Control Bar (Floating Top or Sticky) */}
      <aside aria-label="CMSエディタツールバー" className="sticky top-0 z-50 w-full bg-[#161513]/95 backdrop-blur-md border-b border-[#2e2b27] px-3 sm:px-6 py-2 shadow-xl">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">
          {/* Left: Mode Toggle & CMS Drawer trigger */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-[#23211d] p-1 rounded-lg border border-[#38342f]">
              <button
                onClick={() => setIsEditMode(false)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all cursor-pointer ${
                  !isEditMode
                    ? 'bg-[#b38d4f] text-[#121110] font-bold shadow-sm'
                    : 'text-[#a8a196] hover:text-[#f5f2eb]'
                }`}
                title="通常表示（本番プレビュー）"
              >
                <Eye className="w-3.5 h-3.5" />
                <span className="hidden xs:inline">公開プレビュー</span>
                <span className="xs:hidden">プレビュー</span>
              </button>

              <button
                onClick={() => {
                  setIsEditMode(true);
                  if (!isEditorDrawerOpen) {
                    setIsEditorDrawerOpen(true);
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md transition-all cursor-pointer ${
                  isEditMode
                    ? 'bg-[#b38d4f] text-[#121110] font-bold shadow-sm'
                    : 'text-[#a8a196] hover:text-[#f5f2eb]'
                }`}
                title="編集モード（テキストや写真を変更）"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>編集モード</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse ml-0.5"></span>
              </button>
            </div>

            {isEditMode && (
              <button
                onClick={() => setIsEditorDrawerOpen(!isEditorDrawerOpen)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md border transition-all cursor-pointer ${
                  isEditorDrawerOpen
                    ? 'bg-[#38342f] text-[#f5f2eb] border-[#b38d4f]'
                    : 'bg-[#23211d] text-[#e6dfd5] border-[#38342f] hover:border-[#b38d4f]'
                }`}
              >
                <Sliders className="w-3.5 h-3.5 text-[#b38d4f]" />
                <span className="hidden md:inline">編集パネル</span>
                <span>{isEditorDrawerOpen ? '閉じる' : '開く'}</span>
              </button>
            )}
          </div>

          {/* Center: Device Viewport Switcher */}
          <div className="hidden lg:flex items-center gap-1 bg-[#23211d] p-1 rounded-lg border border-[#38342f]">
            <span className="text-xs text-[#8a8377] px-2">プレビュー幅:</span>
            <button
              onClick={() => setViewportMode('desktop')}
              className={`p-1.5 rounded transition-all cursor-pointer ${
                viewportMode === 'desktop'
                  ? 'bg-[#38342f] text-[#b38d4f]'
                  : 'text-[#8a8377] hover:text-[#f5f2eb]'
              }`}
              title="デスクトップ PC 表示"
            >
              <Laptop className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewportMode('tablet')}
              className={`p-1.5 rounded transition-all cursor-pointer ${
                viewportMode === 'tablet'
                  ? 'bg-[#38342f] text-[#b38d4f]'
                  : 'text-[#8a8377] hover:text-[#f5f2eb]'
              }`}
              title="タブレット表示 (768px)"
            >
              <Tablet className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewportMode('mobile')}
              className={`p-1.5 rounded transition-all cursor-pointer ${
                viewportMode === 'mobile'
                  ? 'bg-[#38342f] text-[#b38d4f]'
                  : 'text-[#8a8377] hover:text-[#f5f2eb]'
              }`}
              title="スマートフォン表示 (375px)"
            >
              <Smartphone className="w-4 h-4" />
            </button>
          </div>

          {/* Right: Quick actions (Reset, Export, Import) */}
          <div className="flex items-center gap-2">
            {isEditMode && (
              <div className="hidden sm:flex items-center gap-1.5">
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      openEditorForSection(e.target.value as EditorTab);
                    }
                  }}
                  className="bg-[#23211d] border border-[#38342f] text-[#e6dfd5] text-xs rounded-md px-2.5 py-1.5 focus:outline-none focus:border-[#b38d4f]"
                  defaultValue=""
                >
                  <option value="" disabled>
                    セクション編集へジャンプ...
                  </option>
                  <option value="hero">ヒーロー / メイン</option>
                  <option value="concept">棟梁の心・コンセプト</option>
                  <option value="works">施工イメージ (追加・編集)</option>
                  <option value="services">サービス一覧</option>
                  <option value="process">施工の流れ (5ステップ)</option>
                  <option value="local">地域密着・こだわり</option>
                  <option value="onrei">オンレイ全館空調システム</option>
                  <option value="aeoSeo">AI・SEO/AEO設計</option>
                  <option value="faq">よくある質問 (FAQ)</option>
                  <option value="company">会社概要・代表挨拶</option>
                  <option value="contact">お問い合わせ設定</option>
                </select>
              </div>
            )}

            <button
              onClick={exportJson}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#23211d] hover:bg-[#2e2b27] border border-[#38342f] text-[#e6dfd5] text-xs transition-colors cursor-pointer"
              title="編集した全データをJSONでダウンロード"
            >
              <Download className="w-3.5 h-3.5 text-[#b38d4f]" />
              <span className="hidden sm:inline">書き出し</span>
            </button>

            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#23211d] hover:bg-[#2e2b27] border border-[#38342f] text-[#e6dfd5] text-xs transition-colors cursor-pointer"
              title="JSONファイルを読み込んで反映"
            >
              <Upload className="w-3.5 h-3.5 text-[#b38d4f]" />
              <span className="hidden sm:inline">読み込み</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />

            <button
              onClick={resetToDefaults}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-md bg-[#23211d] hover:bg-rose-950/40 border border-[#38342f] hover:border-rose-700/60 text-[#a8a196] hover:text-rose-300 text-xs transition-colors cursor-pointer"
              title="初期状態にリセット"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">初期化</span>
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
