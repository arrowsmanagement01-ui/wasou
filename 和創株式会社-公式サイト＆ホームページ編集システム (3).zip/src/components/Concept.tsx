import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Quote } from 'lucide-react';

export const Concept: React.FC = () => {
  const { data } = useSiteData();
  const { concept } = data;

  return (
    <EditableWrapper tab="concept" label="棟梁の心・コンセプト" id="concept">
      <section className="py-20 lg:py-28 bg-[#161513] relative overflow-hidden border-b border-[#2a2723]">
        {/* Subtle Background Koshi Pattern */}
        <div className="absolute inset-0 koshi-pattern opacity-30 pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Section Heading */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm sm:text-base tracking-[0.25em] font-medium block mb-2 [text-wrap:balance]">
              <span className="inline-block">デザインと住み心地を極める</span>
              <span className="inline-block">自由設計の家。</span>
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              <span className="inline-block">和創株式会社</span>
              <span className="inline-block text-[#b38d4f] mx-2">·</span>
              <span className="inline-block">棟梁の心</span>
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#a8a196] tracking-widest uppercase [text-wrap:balance]">
              <span className="inline-block">多彩な意匠と</span>
              <span className="inline-block">確かな職人技術</span>
            </p>
          </div>

          {/* Two-Column Feature: Image + Core Quote */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center mb-20">
            {/* Visual Image with Frame */}
            <div className="lg:col-span-6 relative">
              <div className="relative rounded-sm overflow-hidden border border-[#3e3932] shadow-2xl group">
                <img
                  src={concept.imageUrl || '/assets/interior.jpg'}
                  alt="和創株式会社の自由設計吹き抜けリビング"
                  referrerPolicy="no-referrer"
                  className="w-full h-[380px] sm:h-[460px] object-cover filter brightness-[0.92] group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#121110]/80 via-transparent to-transparent"></div>
                
                {/* Top Right Annotation Badge */}
                <div className="absolute top-3 right-3 pointer-events-none select-none">
                  <span className="px-2.5 py-1 rounded bg-[#121110]/85 border border-[#3e3932] text-[10px] text-[#a8a196] font-medium tracking-wider backdrop-blur-sm">
                    ※イメージ画像
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 bg-[#1a1815]/85 backdrop-blur-md p-3 sm:p-4 rounded border border-[#b38d4f]/30">
                  <p className="text-xs sm:text-sm text-[#f5f2eb] font-serif-jp [text-wrap:balance]">
                    <span className="inline-block">富山県産スギ梁と自然光が生む、</span>
                    <span className="inline-block">心地よい吹き抜けリビング</span>
                    <span className="text-[10px] text-[#a8a196] ml-1">（※イメージ画像）</span>
                  </p>
                </div>
              </div>
              {/* Decorative Corner Borders */}
              <div className="absolute -top-3 -left-3 w-8 h-8 border-t-2 border-l-2 border-[#b38d4f]"></div>
              <div className="absolute -bottom-3 -right-3 w-8 h-8 border-b-2 border-r-2 border-[#b38d4f]"></div>
            </div>

            {/* Philosophy Text */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              <div className="relative pl-6 border-l-2 border-[#b38d4f] mb-6">
                <Quote className="w-7 h-7 text-[#b38d4f]/40 absolute -top-2 left-6" />
                <h3 className="font-serif-jp text-xl sm:text-2xl font-bold text-[#f5f2eb] leading-snug mb-4 pt-2 [text-wrap:balance]">
                  <span className="inline-block">「モダンBOX」</span>
                  <span className="inline-block">「洋風」</span>
                  <span className="inline-block">「平屋」</span>
                  <span className="inline-block">「和モダン」。</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block mt-1 sm:mt-0">あらゆる理想に、</span>
                  <span className="inline-block">職人の魂を込めて。</span>
                </h3>
                <p className="text-sm sm:text-base text-[#dcd6cd] leading-relaxed italic [text-wrap:pretty]">
                  <span className="inline-block">規格住宅にはない自由な発想と、</span>
                  <span className="inline-block">住まう人のライフスタイルに寄り添うデザイン。</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block mt-1 sm:mt-0">木と鉄と光が美しく調和し、</span>
                  <span className="inline-block">時を重ねるほどに愛着が深まる本物の住まい。</span>
                </p>
              </div>

              <div className="space-y-4 text-sm sm:text-base text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                <p>
                  <span className="inline-block">和創株式会社が大切にしているのは、</span>
                  <span className="inline-block">住まい手一人ひとりの「個性と美意識」に応える自由設計です。</span>
                  <span className="inline-block">シンプルでスタイリッシュなモダンBOXタイプ、</span>
                  <span className="inline-block">明るく温かみのある洋風スタイル、</span>
                  <span className="inline-block">ワンフロアでゆったり暮らす平屋、</span>
                  <span className="inline-block">そして日本の美を宿す和モダンまで、</span>
                  <span className="inline-block">多様な建築デザインを高い完成度で実現します。</span>
                </p>
                <p>
                  <span className="inline-block">立山連峰の吹き下ろしや湿気、多雪といった</span>
                  <span className="inline-block">富山ならではの過酷な気候風土を熟知しているからこそ、</span>
                  <span className="inline-block">強固な構造計算と高断熱・高気密施工を徹底。</span>
                  <span className="inline-block">どのようなデザインであっても、</span>
                  <span className="inline-block">一年を通じて心地よく、永く安心して暮らせる住まいをお約束します。</span>
                </p>
              </div>
            </div>
          </div>

          {/* 3 Core Pillars */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 mb-20">
            {concept.features.map((feat) => (
              <div
                key={feat.num}
                className="bg-[#1c1a17] border border-[#2e2a25] hover:border-[#b38d4f]/60 p-6 sm:p-8 rounded-sm shadow-md transition-all duration-300 relative group"
              >
                <div className="text-3xl font-serif-jp font-bold text-[#b38d4f]/60 group-hover:text-[#b38d4f] transition-colors mb-3">
                  {feat.num}
                </div>
                <div className="text-xs text-[#a8a196] tracking-widest uppercase mb-1">
                  {feat.subtitle}
                </div>
                <h4 className="font-serif-jp text-xl font-bold text-[#f5f2eb] mb-3 [text-wrap:balance]">
                  {feat.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                  {feat.description}
                </p>
              </div>
            ))}
          </div>

          {/* Emblem Meaning & Master Message Banner */}
          <div className="bg-[#1f1d19] border border-[#3e3932] rounded-sm p-6 sm:p-10 relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-1/3 koshi-pattern-dense opacity-20 pointer-events-none"></div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-4 flex items-center gap-5">
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#161513] border-2 border-[#b38d4f] p-2 flex items-center justify-center shrink-0 shadow-lg">
                  <img
                    src="/wasou-logo.svg"
                    alt="和創株式会社 ロゴ"
                    className="w-full h-full object-contain invert-[0.9] sepia-[0.3]"
                  />
                </div>
                <div>
                  <h4 className="font-serif-jp text-base sm:text-lg font-bold text-[#f5f2eb] mb-1 [text-wrap:balance]">
                    {concept.emblemTitle}
                  </h4>
                  <p className="text-xs text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                    {concept.emblemDescription}
                  </p>
                </div>
              </div>

              <div className="lg:col-span-8 lg:border-l lg:border-[#38342f] lg:pl-8">
                <p className="font-serif-jp text-base sm:text-lg text-[#f5f2eb] leading-relaxed italic mb-3 [text-wrap:pretty]">
                  「<span className="inline-block">BOXタイプも、洋風も、平屋も、和モダンも。</span>
                  <br className="hidden md:inline" />
                  <span className="inline-block mt-1 md:mt-0">施主様の思い描く理想のデザインを、</span>
                  <span className="inline-block">構造の強さと丁寧な手仕事で形にすることが</span>
                  <span className="inline-block">和創の誇りです。</span>」
                </p>
                <p className="text-right text-xs sm:text-sm text-[#b38d4f] font-medium">
                  ― {concept.masterAuthor}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
