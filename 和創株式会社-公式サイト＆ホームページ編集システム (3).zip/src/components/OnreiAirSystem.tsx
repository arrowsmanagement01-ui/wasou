import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { OnreiGalleryItem } from '../types/siteData';
import {
  Wind,
  Sparkles,
  ThermometerSun,
  ShieldCheck,
  CheckCircle2,
  ExternalLink,
  Zap,
  Award,
  Layers,
  Sun,
  Snowflake,
  Flower2,
  ChevronRight,
  BadgeCheck,
  Building2,
  Maximize2,
  X,
  Camera,
  Check,
} from 'lucide-react';

export const OnreiAirSystem: React.FC = () => {
  const { data } = useSiteData();
  const { onreiSystem } = data;
  const [selectedSeason, setSelectedSeason] = useState<string>('winter');
  const [activeModalImage, setActiveModalImage] = useState<OnreiGalleryItem | null>(null);

  const getBenefitIcon = (iconName: string) => {
    switch (iconName) {
      case 'ThermometerSun':
        return <ThermometerSun className="w-6 h-6 text-[#b38d4f]" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-[#b38d4f]" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-[#b38d4f]" />;
      case 'Layers':
        return <Layers className="w-6 h-6 text-[#b38d4f]" />;
      case 'ShieldCheck':
      default:
        return <ShieldCheck className="w-6 h-6 text-[#b38d4f]" />;
    }
  };

  const getSeasonIcon = (season: string) => {
    switch (season) {
      case 'winter':
        return <Snowflake className="w-5 h-5 text-sky-400" />;
      case 'summer':
        return <Sun className="w-5 h-5 text-amber-400" />;
      case 'spring_autumn':
      default:
        return <Flower2 className="w-5 h-5 text-emerald-400" />;
    }
  };

  const handleConsultClick = () => {
    const contactEl = document.getElementById('contact');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth' });
      setTimeout(() => {
        const select = document.getElementById('consultation-type') as HTMLSelectElement | null;
        if (select) {
          select.value = 'オンレイ全館空調システムのご相談';
        }
      }, 300);
    }
  };

  const currentSeasonData =
    onreiSystem.seasonalFeatures.find((s) => s.season === selectedSeason) ||
    onreiSystem.seasonalFeatures[0];

  return (
    <EditableWrapper tab="onrei" label="オンレイ全館空調システム" id="onrei">
      <section className="py-20 lg:py-28 bg-[#141311] relative border-b border-[#2a2723] overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-[#b38d4f]/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          {/* Header Section */}
          <div className="text-center max-w-3xl mx-auto mb-14">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#23201a] border border-[#b38d4f]/40 text-[#b38d4f] text-xs font-semibold tracking-wider mb-4 shadow-inner">
              <BadgeCheck className="w-4 h-4 text-[#b38d4f]" />
              <span>{onreiSystem.partnerBadge}</span>
            </div>

            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-4 leading-tight [text-wrap:balance]">
              <span className="inline-block">住みたくなる家は、</span>
              <span className="inline-block">空気質でデザインする</span>
            </h2>
            <div className="w-16 h-0.5 bg-[#b38d4f] mx-auto mb-5" />
            <p className="font-serif-jp text-sm sm:text-base text-[#e6dfd5] font-medium mb-3 [text-wrap:balance]">
              <span className="inline-block">和創株式会社は、</span>
              <span className="inline-block">株式会社オンレイの</span>
              <br className="hidden sm:inline" />
              <span className="inline-block">次世代全館空調・高性能換気システムの</span>
              <span className="inline-block">正規導入店舗です。</span>
            </p>
            <p className="text-xs sm:text-sm text-[#a8a196] leading-relaxed max-w-2xl mx-auto [text-wrap:pretty]">
              <span className="inline-block">寒暖差の激しい北陸・富山の気候だからこそ、</span>
              <span className="inline-block">住まいの「温熱環境」と「空気の質」は</span>
              <span className="inline-block">ご家族の健康と直結します。</span>
              <br className="hidden sm:inline" />
              <span className="inline-block mt-1 sm:mt-0">和創では、累計10,000棟以上の導入実績を誇る</span>
              <span className="inline-block">空調・換気システムメーカー「株式会社オンレイ（ONREI）」の正規パートナーとして、</span>
              <span className="inline-block">高気密・高断熱住宅に最適化された先進の全館空調システムをご提案・施工しています。</span>
            </p>
          </div>

          {/* Official Partner Introduction Card with Quoted Main Visual Photo */}
          <div className="bg-gradient-to-br from-[#1c1a17] via-[#221f1a] to-[#1c1a17] border border-[#3d362c] rounded-xl overflow-hidden mb-16 shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-0">
              {/* Photo Area (Cited from onrei.jp) */}
              <div className="lg:col-span-7 relative group overflow-hidden bg-[#11100e] min-h-[300px] sm:min-h-[400px]">
                <img
                  src={onreiSystem.heroImage || '/images/onrei/mv.webp'}
                  alt="オンレイ全館空調システム 快適な住まいイメージ"
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 brightness-95"
                  onError={(e) => {
                    const target = e.currentTarget;
                    if (!target.src.includes('onrei.jp')) {
                      target.src =
                        'https://onrei.jp/2025wp-air/wp-content/themes/onrei-2025/assets/images/corporate/mv.webp';
                    }
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#141311] via-transparent to-transparent opacity-80 lg:hidden" />
                
                {/* Photo Citation Badge Overlay */}
                <div className="absolute bottom-3 left-3 right-3 sm:right-auto bg-[#141311]/85 backdrop-blur-md border border-[#3d362c] rounded px-3 py-1.5 flex items-center gap-2 text-[10px] text-[#c5bcad] shadow-lg">
                  <Camera className="w-3.5 h-3.5 text-[#b38d4f] shrink-0" />
                  <span className="leading-tight">
                    写真引用：
                    <a
                      href={onreiSystem.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#b38d4f] hover:underline ml-1 font-semibold"
                    >
                      株式会社オンレイ公式サイト（onrei.jp）
                    </a>
                  </span>
                </div>
              </div>

              {/* Text & Partner Credential Area */}
              <div className="lg:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-[10px] font-bold text-[#141311] bg-[#b38d4f] px-2.5 py-0.5 rounded uppercase tracking-wider">
                      Authorized Partner
                    </span>
                    <span className="text-xs text-[#dcd6cd] flex items-center gap-1.5 font-medium">
                      <Building2 className="w-3.5 h-3.5 text-[#b38d4f]" />
                      株式会社オンレイ（ONREI）公式導入店舗
                    </span>
                  </div>

                  <h3 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] leading-snug [text-wrap:balance]">
                    <span className="inline-block">空気質（IAQ）で</span>
                    <span className="inline-block">住まいをデザインする</span>
                    <br className="hidden sm:inline" />
                    <span className="inline-block mt-1 sm:mt-0">先進空調テクノロジー</span>
                  </h3>

                  <p className="text-xs sm:text-sm text-[#b8b0a2] leading-relaxed [text-wrap:pretty]">
                    <span className="inline-block">株式会社オンレイ（本社：東京都墨田区 / URL: https://onrei.jp）は、</span>
                    <span className="inline-block">2011年の創業以来「空気質で住まいをデザインする」先進技術メーカーです。</span>
                    <br className="hidden sm:inline" />
                    <span className="inline-block mt-1 sm:mt-0">業界初となる高濃度マイナスイオン発生装置付き全館空調「CLEnAIR（クリネア）」をはじめ、</span>
                    <span className="inline-block">世界最高水準の熱交換効率を誇る換気システムなどを独自開発し、</span>
                    <span className="inline-block">全国の厳選された工務店とともに快適な住空間を届けています。</span>
                  </p>

                  <div className="space-y-2.5 pt-2 text-xs text-[#dcd6cd]">
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#b38d4f] shrink-0 mt-0.5" />
                      <span>累計10,000棟以上の導入実績（全国の工務店で確固たる支持）</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#b38d4f] shrink-0 mt-0.5" />
                      <span>和創は設計・ダクト風量計算・自社大工施工まで一貫対応</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#b38d4f] shrink-0 mt-0.5" />
                      <span>富山の多湿な夏と氷点下の底冷えを解消する高断熱連携</span>
                    </div>
                  </div>
                </div>

                {/* Direct Link to ONREI Official Site */}
                <div className="pt-4 border-t border-[#2e2a24]">
                  <a
                    href={onreiSystem.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded bg-[#2a2620] hover:bg-[#342f27] border border-[#b38d4f]/70 text-[#f5f2eb] text-xs sm:text-sm font-semibold tracking-wide transition-all shadow-md group"
                  >
                    <span>株式会社オンレイ 公式Webサイト</span>
                    <ExternalLink className="w-4 h-4 text-[#b38d4f] group-hover:translate-x-0.5 transition-transform" />
                  </a>
                  <p className="text-[10px] text-[#8a8377] text-center mt-2">
                    ※外部サイト（onrei.jp）へリンクします
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 3 Main Systems (CLEnAIR, PROnAIR, ECO床暖 & EVOnAIR) with Photos */}
          <div className="mb-20">
            <div className="text-center mb-10">
              <span className="text-[#b38d4f] text-xs font-semibold tracking-widest uppercase block mb-1">
                SYSTEM LINEUP & PHOTOGRAPHS
              </span>
              <h3 className="font-serif-jp text-xl sm:text-3xl font-bold text-[#f5f2eb] [text-wrap:balance]">
                <span className="inline-block">導入している3つの先進テクノロジーと</span>
                <span className="inline-block">製品写真</span>
              </h3>
              <p className="text-xs text-[#a8a196] mt-2">
                写真引用元：株式会社オンレイ 公式サイト（https://onrei.jp/）
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
              {onreiSystem.systems.map((sys) => (
                <div
                  key={sys.id}
                  className="bg-[#181715] border border-[#2e2a25] hover:border-[#b38d4f]/70 rounded-lg overflow-hidden flex flex-col justify-between transition-all duration-300 shadow-xl group"
                >
                  <div>
                    {/* System Photo with Citation */}
                    {sys.imageUrl && (
                      <div className="relative h-48 overflow-hidden bg-[#0f0e0c]">
                        <img
                          src={sys.imageUrl}
                          alt={`${sys.name} システム写真`}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-90"
                          onError={(e) => {
                            const target = e.currentTarget;
                            if (sys.id === 'system-clenair') {
                              target.src =
                                'https://onrei.jp/2025wp-air/wp-content/themes/onrei-2025/assets/images/corporate/srvc_cle_img.webp';
                            } else if (sys.id === 'system-pronair') {
                              target.src =
                                'https://onrei.jp/2025wp-air/wp-content/themes/onrei-2025/assets/images/corporate/srvc_pro_img.webp';
                            } else {
                              target.src =
                                'https://onrei.jp/2025wp-air/wp-content/themes/onrei-2025/assets/images/corporate/srvc_evo_img.webp';
                            }
                          }}
                        />
                        <div className="absolute top-3 right-3">
                          <span className="inline-block text-[10px] font-bold tracking-wider text-[#141311] bg-[#b38d4f] px-2.5 py-0.5 rounded shadow whitespace-nowrap">
                            {sys.highlightTag}
                          </span>
                        </div>
                        <div className="absolute bottom-2 left-2 bg-[#141311]/80 backdrop-blur-xs px-2 py-0.5 rounded text-[9px] text-[#b8b0a2]">
                          写真引用：株式会社オンレイ
                        </div>
                      </div>
                    )}

                    <div className="p-6">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 rounded bg-[#23201a] border border-[#3d362c] flex items-center justify-center text-[#b38d4f] shrink-0 group-hover:border-[#b38d4f] transition-colors">
                          {sys.id === 'system-clenair' ? (
                            <Sparkles className="w-5 h-5" />
                          ) : sys.id === 'system-pronair' ? (
                            <Wind className="w-5 h-5" />
                          ) : (
                            <ThermometerSun className="w-5 h-5" />
                          )}
                        </div>
                        <div>
                          <h4 className="font-serif-jp text-lg font-bold text-[#f5f2eb] [text-wrap:balance]">
                            {sys.name}
                          </h4>
                          <span className="text-[10px] text-[#8a8377] font-mono block uppercase tracking-wider">
                            {sys.englishName}
                          </span>
                        </div>
                      </div>

                      <p className="text-xs font-semibold text-[#b38d4f] mb-3 leading-relaxed [text-wrap:pretty]">
                        {sys.tagline}
                      </p>
                      <p className="text-xs text-[#a8a196] leading-relaxed mb-5 [text-wrap:pretty]">
                        {sys.description}
                      </p>
                    </div>
                  </div>

                  {/* Bullet points */}
                  <div className="px-6 pb-6 pt-3 border-t border-[#26231f]">
                    <span className="text-[11px] font-bold text-[#dcd6cd] block mb-2">
                      主な性能・特長：
                    </span>
                    <ul className="space-y-2">
                      {sys.features.map((feat, fIdx) => (
                        <li key={fIdx} className="flex items-start gap-2 text-xs text-[#b8b0a2] [text-wrap:pretty]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#b38d4f] shrink-0 mt-0.5" />
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* REAL IMPLEMENTATION PHOTO GALLERY (オンレイ全館空調 導入写真ギャラリー) */}
          <div className="mb-20">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
              <div>
                <div className="inline-flex items-center gap-2 text-[#b38d4f] text-xs font-semibold tracking-widest uppercase mb-1">
                  <Camera className="w-3.5 h-3.5" />
                  <span>ONREI SPACE GALLERY</span>
                </div>
                <h3 className="font-serif-jp text-xl sm:text-3xl font-bold text-[#f5f2eb] [text-wrap:balance]">
                  <span className="inline-block">オンレイ全館空調</span>
                  <span className="inline-block">空間実例ギャラリー</span>
                </h3>
              </div>
              <div className="text-left md:text-right">
                <span className="text-[11px] text-[#a8a196] block">
                  写真をクリックすると拡大表示できます
                </span>
                <span className="text-[10px] text-[#b38d4f]">
                  写真引用：株式会社オンレイ（onrei.jp）
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {onreiSystem.gallery.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setActiveModalImage(item)}
                  className="group bg-[#191815] border border-[#2e2a25] hover:border-[#b38d4f] rounded-lg overflow-hidden cursor-pointer transition-all duration-300 shadow-md flex flex-col justify-between"
                >
                  <div className="relative h-48 overflow-hidden bg-[#11100e]">
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 brightness-90"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (!target.src.includes('onrei.jp')) {
                          target.src = `https://onrei.jp/2025wp-air/wp-content/themes/onrei-2025/assets/images/corporate/${item.imageUrl.split('/').pop()}`;
                        }
                      }}
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-colors" />
                    
                    <div className="absolute top-2.5 left-2.5">
                      <span className="text-[9px] font-bold text-[#f5f2eb] bg-[#141311]/85 backdrop-blur-xs px-2 py-0.5 rounded border border-[#3d362c]">
                        {item.tag}
                      </span>
                    </div>

                    <div className="absolute bottom-2.5 right-2.5 w-7 h-7 rounded-full bg-[#141311]/80 backdrop-blur-xs flex items-center justify-center text-[#b38d4f] opacity-80 group-hover:opacity-100 transition-opacity">
                      <Maximize2 className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-serif-jp text-sm font-bold text-[#f5f2eb] mb-1.5 group-hover:text-[#b38d4f] transition-colors [text-wrap:balance]">
                        {item.title}
                      </h4>
                      <p className="text-xs text-[#a8a196] leading-relaxed line-clamp-2 [text-wrap:pretty]">
                        {item.caption}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-[#26231f] flex items-center justify-between text-[10px] text-[#787268]">
                      <span>引用元：onrei.jp</span>
                      <span className="text-[#b38d4f] group-hover:translate-x-0.5 transition-transform">
                        拡大見る →
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* General citation notice footer */}
            <div className="mt-4 p-3 bg-[#191714] border border-[#2a2621] rounded text-[11px] text-[#8a8377] flex items-center gap-2">
              <Camera className="w-3.5 h-3.5 text-[#b38d4f] shrink-0" />
              <span>{onreiSystem.citationNotice}</span>
            </div>
          </div>

          {/* 5 Big Merits for Homeowners */}
          <div className="mb-20">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-[#b38d4f] text-xs font-semibold tracking-widest uppercase block mb-1">
                KEY BENEFITS
              </span>
              <h3 className="font-serif-jp text-xl sm:text-3xl font-bold text-[#f5f2eb] mb-3 [text-wrap:balance]">
                <span className="inline-block">施主様に選ばれる</span>
                <span className="inline-block">5大メリット</span>
              </h3>
              <p className="text-xs sm:text-sm text-[#a8a196] [text-wrap:pretty] max-w-xl mx-auto">
                <span className="inline-block">一般的な個別エアコン設置住宅と比較して、</span>
                <span className="inline-block">日々の暮らしの快適性・健康・光熱費・美観が</span>
                <span className="inline-block">劇的に向上します。</span>
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {onreiSystem.benefits.map((benefit, idx) => (
                <div
                  key={benefit.id}
                  className={`bg-[#191815] border border-[#2e2a25] hover:border-[#b38d4f]/60 rounded-md p-6 sm:p-7 transition-all duration-300 shadow-md group flex flex-col justify-between ${
                    idx === 4 ? 'md:col-span-2 lg:col-span-1' : ''
                  }`}
                >
                  <div>
                    {/* Top Row */}
                    <div className="flex items-center justify-between mb-4">
                      <span className="font-serif-jp text-2xl font-bold text-[#b38d4f]/60">
                        {benefit.num}
                      </span>
                      <span className="text-[10px] font-bold text-[#b38d4f] bg-[#b38d4f]/10 border border-[#b38d4f]/30 px-2.5 py-0.5 rounded">
                        {benefit.badge}
                      </span>
                    </div>

                    <div className="w-10 h-10 rounded bg-[#23201a] border border-[#38332b] flex items-center justify-center mb-4 group-hover:border-[#b38d4f] transition-colors">
                      {getBenefitIcon(benefit.iconName)}
                    </div>

                    <h4 className="font-serif-jp text-base sm:text-lg font-bold text-[#f5f2eb] mb-1.5 [text-wrap:balance]">
                      {benefit.title}
                    </h4>
                    <p className="text-xs text-[#b38d4f] font-medium mb-3 leading-snug [text-wrap:balance]">
                      {benefit.subtitle}
                    </p>
                    <p className="text-xs text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Seasonal Simulation Interactive Block */}
          <div className="bg-[#181715] border border-[#302c26] rounded-xl p-6 sm:p-10 mb-16 shadow-xl">
            <div className="text-center max-w-2xl mx-auto mb-8">
              <span className="text-[#b38d4f] text-xs font-semibold tracking-widest uppercase block mb-1">
                ALL-SEASON COMFORT
              </span>
              <h3 className="font-serif-jp text-xl sm:text-2xl font-bold text-[#f5f2eb] mb-2 [text-wrap:balance]">
                <span className="inline-block">富山の厳しい四季を快適に変える</span>
                <span className="inline-block">シミュレーション</span>
              </h3>
              <p className="text-xs text-[#a8a196] [text-wrap:pretty]">
                <span className="inline-block">季節をタップして、</span>
                <span className="inline-block">オンレイ全館空調がもたらす住み心地の違いをご確認ください。</span>
              </p>
            </div>

            {/* Season Selector Tabs */}
            <div className="flex justify-center mb-8">
              <div className="inline-flex p-1 rounded-lg bg-[#121110] border border-[#2a2622]">
                {onreiSystem.seasonalFeatures.map((season) => {
                  const isActive = selectedSeason === season.season;
                  return (
                    <button
                      key={season.season}
                      onClick={() => setSelectedSeason(season.season)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-md text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                        isActive
                          ? 'bg-[#b38d4f] text-[#121110] shadow-md font-bold'
                          : 'text-[#a8a196] hover:text-[#f5f2eb]'
                      }`}
                    >
                      {getSeasonIcon(season.season)}
                      <span>{season.seasonLabel}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Selected Season Detail Card */}
            <div className="bg-[#1f1d19] border border-[#38332b] rounded-lg p-6 sm:p-8 animate-fadeIn">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="space-y-3 flex-1">
                  <div className="flex items-center gap-2">
                    {getSeasonIcon(currentSeasonData.season)}
                    <span className="text-xs font-bold text-[#b38d4f] tracking-wider uppercase">
                      {currentSeasonData.seasonLabel}の快適設計
                    </span>
                  </div>
                  <h4 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] [text-wrap:balance]">
                    {currentSeasonData.title}
                  </h4>
                  <p className="text-xs sm:text-sm text-[#c5bcad] leading-relaxed [text-wrap:pretty]">
                    {currentSeasonData.description}
                  </p>
                </div>

                <div className="lg:w-1/2 pt-4 lg:pt-0 lg:pl-6 lg:border-l border-[#2e2a24]">
                  <span className="text-xs font-bold text-[#f5f2eb] block mb-3">
                    オンレイ全館空調が解決するポイント：
                  </span>
                  <ul className="space-y-2.5">
                    {currentSeasonData.meritPoints.map((pt, pIdx) => (
                      <li key={pIdx} className="flex items-start gap-2.5 text-xs text-[#dcd6cd] [text-wrap:pretty]">
                        <CheckCircle2 className="w-4 h-4 text-[#b38d4f] shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Craftsmanship & Warranty Double Assurance Card */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
            <div className="bg-[#181715] border border-[#2e2a25] rounded-xl p-6 sm:p-7 shadow-lg">
              <div className="flex items-center gap-2.5 mb-3">
                <Award className="w-5 h-5 text-[#b38d4f]" />
                <h4 className="font-serif-jp text-base font-bold text-[#f5f2eb] [text-wrap:balance]">
                  和創の自社大工による高精度施工
                </h4>
              </div>
              <p className="text-xs text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                {onreiSystem.craftsmanshipNote}
              </p>
            </div>

            <div className="bg-[#181715] border border-[#2e2a25] rounded-xl p-6 sm:p-7 shadow-lg">
              <div className="flex items-center gap-2.5 mb-3">
                <ShieldCheck className="w-5 h-5 text-[#b38d4f]" />
                <h4 className="font-serif-jp text-base font-bold text-[#f5f2eb] [text-wrap:balance]">
                  安心の長期保証＆アフターサポート
                </h4>
              </div>
              <p className="text-xs text-[#a8a196] leading-relaxed [text-wrap:pretty]">
                {onreiSystem.warrantyInfo}
              </p>
            </div>
          </div>

          {/* Consultation CTA Banner */}
          <div className="bg-gradient-to-r from-[#211e18] via-[#262118] to-[#211e18] border border-[#b38d4f]/50 rounded-xl p-6 sm:p-10 text-center shadow-2xl">
            <h3 className="font-serif-jp text-lg sm:text-2xl font-bold text-[#f5f2eb] mb-3 [text-wrap:balance]">
              <span className="inline-block">オンレイ全館空調の導入や</span>
              <span className="inline-block">間取り・光熱費について</span>
              <br className="hidden sm:inline" />
              <span className="inline-block">聞いてみませんか？</span>
            </h3>
            <p className="text-xs sm:text-sm text-[#c5bcad] max-w-xl mx-auto mb-6 leading-relaxed [text-wrap:pretty]">
              <span className="inline-block">新築の注文建築はもちろん、</span>
              <span className="inline-block">リフォーム・リノベーションでの空調刷新もご相談いただけます。</span>
              <br className="hidden sm:inline" />
              <span className="inline-block mt-1 sm:mt-0">専任スタッフが間取りやご予算に応じた最適なプランを</span>
              <span className="inline-block">無料でお見積りいたします。</span>
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={handleConsultClick}
                className="w-full sm:w-auto px-8 py-3.5 rounded bg-[#b38d4f] hover:bg-[#c49d5c] text-[#121110] font-bold text-xs sm:text-sm tracking-wider transition-all duration-300 shadow-lg cursor-pointer flex items-center justify-center gap-2"
              >
                <span>オンレイ全館空調について無料で相談する</span>
                <ChevronRight className="w-4 h-4" />
              </button>
              <a
                href={onreiSystem.officialUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-3.5 rounded bg-[#1f1d19] hover:bg-[#282520] border border-[#3d372e] text-[#dcd6cd] hover:text-[#f5f2eb] text-xs sm:text-sm font-medium transition-colors flex items-center justify-center gap-2"
              >
                <span>株式会社オンレイ 公式サイト</span>
                <ExternalLink className="w-4 h-4 text-[#b38d4f]" />
              </a>
            </div>
          </div>
        </div>

        {/* Image Zoom Modal */}
        {activeModalImage && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
            onClick={() => setActiveModalImage(null)}
          >
            <div
              className="bg-[#1c1a17] border border-[#3d362c] rounded-xl max-w-3xl w-full overflow-hidden shadow-2xl relative animate-fadeIn"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setActiveModalImage(null)}
                className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-black/60 text-white hover:bg-black flex items-center justify-center transition-colors cursor-pointer"
                aria-label="閉じる"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative max-h-[60vh] bg-black flex items-center justify-center overflow-hidden">
                <img
                  src={activeModalImage.imageUrl}
                  alt={activeModalImage.title}
                  className="max-h-[60vh] w-auto object-contain"
                />
                <div className="absolute top-4 left-4">
                  <span className="text-xs font-bold text-white bg-[#b38d4f] px-3 py-1 rounded shadow">
                    {activeModalImage.tag}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h4 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] mb-2">
                  {activeModalImage.title}
                </h4>
                <p className="text-xs sm:text-sm text-[#b8b0a2] leading-relaxed mb-4">
                  {activeModalImage.caption}
                </p>
                <div className="pt-3 border-t border-[#2e2a24] flex items-center justify-between text-xs text-[#8a8377]">
                  <span className="flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-[#b38d4f]" />
                    写真引用元：
                    <a
                      href={onreiSystem.officialUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[#b38d4f] hover:underline"
                    >
                      株式会社オンレイ公式サイト（https://onrei.jp/）
                    </a>
                  </span>
                  <button
                    onClick={() => setActiveModalImage(null)}
                    className="text-xs text-[#dcd6cd] hover:text-white px-3 py-1 bg-[#282520] rounded border border-[#3d362c] cursor-pointer"
                  >
                    閉じる
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>
    </EditableWrapper>
  );
};
