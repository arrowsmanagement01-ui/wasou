import React, { useState } from 'react';
import { useSiteData, EditorTab } from '../context/SiteContext';
import { WorkItem } from '../types/siteData';
import {
  X,
  Save,
  RotateCcw,
  Plus,
  Trash2,
  Edit,
  Sparkles,
  Home,
  CheckCircle,
  Layers,
  FileText,
  User,
  HelpCircle,
  Send,
  Building,
  Wind,
} from 'lucide-react';

export const EditorDrawer: React.FC = () => {
  const {
    data,
    updateCompany,
    updateHero,
    updateConcept,
    updateWork,
    addWork,
    deleteWork,
    updateServices,
    updateLocalFocus,
    updateOnreiSystem,
    updateAeoSeo,
    updateFaq,
    updateContact,
    isEditorDrawerOpen,
    setIsEditorDrawerOpen,
    activeEditorTab,
    setActiveEditorTab,
    resetToDefaults,
    exportJson,
  } = useSiteData();

  // Temporary state for adding or editing a single work
  const [editingWorkId, setEditingWorkId] = useState<string | null>(null);
  const [newWorkForm, setNewWorkForm] = useState<Partial<WorkItem>>({
    title: '',
    category: 'モダンBOX',
    location: '',
    completionDate: '2026年竣工',
    floorArea: '150.0㎡',
    structure: '木造軸組金物工法',
    insulation: '断熱等性能等級6 (HEAT20 G2)',
    facadeSpec: 'スクエアBOX外観・中庭テラス',
    description: '',
    highlights: ['モダンBOXデザイン', '富山県産木材活用', '高断熱・高気密設計'],
    imageUrl: '/assets/box_house.jpg',
  });

  if (!isEditorDrawerOpen) return null;

  const tabs: { id: EditorTab; label: string; icon: React.ReactNode }[] = [
    { id: 'hero', label: 'メイン (Hero)', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'concept', label: 'コンセプト', icon: <FileText className="w-4 h-4" /> },
    { id: 'works', label: '施工イメージ (Works)', icon: <Layers className="w-4 h-4" /> },
    { id: 'services', label: 'サービス一覧', icon: <Home className="w-4 h-4" /> },
    { id: 'local', label: '地域密着・こだわり', icon: <User className="w-4 h-4" /> },
    { id: 'onrei', label: 'オンレイ全館空調', icon: <Wind className="w-4 h-4" /> },
    { id: 'aeoSeo', label: 'AI・SEO/AEO', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'company', label: '会社概要・代表挨拶', icon: <Building className="w-4 h-4" /> },
    { id: 'faq', label: 'よくある質問 (FAQ)', icon: <HelpCircle className="w-4 h-4" /> },
    { id: 'contact', label: 'お問い合わせ設定', icon: <Send className="w-4 h-4" /> },
  ];

  return (
    <aside
      aria-label="ホームページコンテンツ編集パネル"
      className="fixed inset-y-0 right-0 z-50 w-full sm:w-[620px] lg:w-[700px] bg-[#161513] border-l border-[#38342f] shadow-2xl flex flex-col animate-slideLeft"
    >
      {/* Top Header */}
      <div className="p-4 sm:p-5 bg-[#1a1815] border-b border-[#2e2a25] flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded bg-[#b38d4f]/20 border border-[#b38d4f]/60 flex items-center justify-center text-[#b38d4f]">
            <Edit className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-serif-jp text-base font-bold text-[#f5f2eb]">
              ホームページ 編集パネル
            </h2>
            <p className="text-[11px] text-[#a8a196]">
              入力した内容はリアルタイムでサイトに反映されます
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportJson}
            className="px-2.5 py-1.5 rounded bg-[#23211d] hover:bg-[#2b2722] border border-[#38342f] text-xs text-[#e6dfd5] transition-colors"
            title="JSON書き出し"
          >
            保存データ書出
          </button>
          <button
            onClick={() => setIsEditorDrawerOpen(false)}
            className="p-1.5 rounded-full bg-[#23211d] hover:bg-rose-950/40 text-[#a8a196] hover:text-white transition-colors cursor-pointer"
            aria-label="編集パネルを閉じる"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-1.5 p-2 bg-[#121110] border-b border-[#282622] overflow-x-auto no-scrollbar shrink-0">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveEditorTab(tab.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-sm text-xs whitespace-nowrap transition-all cursor-pointer ${
              activeEditorTab === tab.id
                ? 'bg-[#b38d4f] text-[#121110] font-bold shadow-sm'
                : 'text-[#a8a196] hover:text-[#f5f2eb] hover:bg-[#1f1d19]'
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Main Tab Content Body (Scrollable) */}
      <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6 text-xs sm:text-sm">
        {/* ==================== HERO TAB ==================== */}
        {activeEditorTab === 'hero' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              メインビジュアル（ヒーローセクション）編集
            </h4>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                上部バッジ（キャッチフレーズ）
              </label>
              <input
                type="text"
                value={data.hero.badge}
                onChange={(e) => updateHero({ badge: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  メイン見出し 1行目
                </label>
                <input
                  type="text"
                  value={data.hero.mainTitlePart1}
                  onChange={(e) => updateHero({ mainTitlePart1: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  地域ハイライト文字列
                </label>
                <input
                  type="text"
                  value={data.hero.cityHighlight}
                  onChange={(e) => updateHero({ cityHighlight: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                メイン見出し 2行目接尾辞
              </label>
              <input
                type="text"
                value={data.hero.mainTitlePart2}
                onChange={(e) => updateHero({ mainTitlePart2: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                サブタイトル（リード文 1）
              </label>
              <textarea
                rows={2}
                value={data.hero.subTitle}
                onChange={(e) => updateHero({ subTitle: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                説明文（リード文 2）
              </label>
              <textarea
                rows={2}
                value={data.hero.description}
                onChange={(e) => updateHero({ description: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                背景写真のURL
              </label>
              <input
                type="text"
                value={data.hero.bgImageUrl}
                onChange={(e) => updateHero({ bgImageUrl: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
              <p className="text-[11px] text-[#8a8377] mt-1">
                ※「/assets/hero.jpg」「/assets/interior.jpg」などのローカル資産または外部画像URLを指定できます。
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                特徴ピル（カンマ区切りで入力）
              </label>
              <input
                type="text"
                value={data.hero.featurePills.join(', ')}
                onChange={(e) =>
                  updateHero({
                    featurePills: e.target.value.split(',').map((s) => s.trim()).filter(Boolean),
                  })
                }
                className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  主要CTAボタン文言
                </label>
                <input
                  type="text"
                  value={data.hero.ctaPrimaryText}
                  onChange={(e) => updateHero({ ctaPrimaryText: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  第2ボタン文言
                </label>
                <input
                  type="text"
                  value={data.hero.ctaSecondaryText}
                  onChange={(e) => updateHero({ ctaSecondaryText: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] focus:border-[#b38d4f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================== CONCEPT TAB ==================== */}
        {activeEditorTab === 'concept' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              棟梁の心・コンセプト編集
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  セクション上部タグ
                </label>
                <input
                  type="text"
                  value={data.concept.sectionTag}
                  onChange={(e) => updateConcept({ sectionTag: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                  メインタイトル
                </label>
                <input
                  type="text"
                  value={data.concept.mainTitle}
                  onChange={(e) => updateConcept({ mainTitle: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                デザインについての引用見出し
              </label>
              <input
                type="text"
                value={data.concept.quoteTitle}
                onChange={(e) => updateConcept({ quoteTitle: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                住まいの知恵・引用文
              </label>
              <textarea
                rows={3}
                value={data.concept.quoteContent}
                onChange={(e) => updateConcept({ quoteContent: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                本文段落 1
              </label>
              <textarea
                rows={3}
                value={data.concept.bodyParagraph1}
                onChange={(e) => updateConcept({ bodyParagraph1: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                本文段落 2
              </label>
              <textarea
                rows={3}
                value={data.concept.bodyParagraph2}
                onChange={(e) => updateConcept({ bodyParagraph2: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                棟梁メッセージ引用
              </label>
              <textarea
                rows={2}
                value={data.concept.masterQuote}
                onChange={(e) => updateConcept({ masterQuote: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#dcd6cd] mb-1">
                棟梁メッセージ署名
              </label>
              <input
                type="text"
                value={data.concept.masterAuthor}
                onChange={(e) => updateConcept({ masterAuthor: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>
          </div>
        )}

        {/* ==================== WORKS TAB ==================== */}
        {activeEditorTab === 'works' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
                施工イメージ一覧（追加・変更・削除）
              </h4>
              <button
                onClick={() => {
                  setEditingWorkId('new');
                  setNewWorkForm({
                    id: `work-${Date.now()}`,
                    title: '新着：魚津のモダンBOX注文邸宅',
                    category: 'モダンBOX',
                    location: '',
                    completionDate: '2026年竣工',
                    floorArea: '150.0㎡',
                    structure: '木造軸組金物工法',
                    insulation: '断熱等級6 (HEAT20 G2)',
                    facadeSpec: 'スクエアBOX外観・中庭テラス',
                    description: '新規追加された施工イメージの説明文です。',
                    highlights: ['モダンBOXデザイン', '高断熱外皮設計', '富山県産木材'],
                    imageUrl: '/assets/box_house.jpg',
                  });
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded bg-[#b38d4f] text-[#121110] font-bold text-xs cursor-pointer hover:bg-[#c59b57]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>新規施工イメージを追加</span>
              </button>
            </div>

            {/* List existing works */}
            <div className="space-y-3">
              {data.works.map((w) => (
                <div
                  key={w.id}
                  className="p-3 bg-[#121110] border border-[#2e2a25] rounded flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 overflow-hidden">
                    <img
                      src={w.imageUrl}
                      alt={w.title}
                      className="w-12 h-12 object-cover rounded shrink-0 border border-[#38342f]"
                    />
                    <div className="truncate">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-[#b38d4f] bg-[#b38d4f]/10 px-1.5 py-0.5 rounded">
                          {w.category}
                        </span>
                      </div>
                      <p className="font-serif-jp text-xs sm:text-sm font-bold text-[#f5f2eb] truncate">
                        {w.title}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => {
                        setEditingWorkId(w.id);
                        setNewWorkForm({ ...w });
                      }}
                      className="p-1.5 rounded bg-[#23211d] hover:bg-[#38342f] text-[#b38d4f]"
                      title="編集"
                    >
                      <Edit className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteWork(w.id)}
                      className="p-1.5 rounded bg-[#23211d] hover:bg-rose-950 text-rose-400"
                      title="削除"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Edit / Add Modal or Inline Form */}
            {editingWorkId && (
              <div className="p-4 sm:p-5 bg-[#181715] border border-[#b38d4f] rounded-sm space-y-3 mt-4">
                <div className="flex items-center justify-between border-b border-[#2e2a25] pb-2">
                  <span className="font-serif-jp font-bold text-sm text-[#b38d4f]">
                    {editingWorkId === 'new' ? '＋ 新規施工イメージの作成' : '施工イメージの編集'}
                  </span>
                  <button
                    onClick={() => setEditingWorkId(null)}
                    className="text-[#8a8377] hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div>
                  <label className="block text-xs text-[#dcd6cd] mb-1">タイトル</label>
                  <input
                    type="text"
                    value={newWorkForm.title || ''}
                    onChange={(e) => setNewWorkForm({ ...newWorkForm, title: e.target.value })}
                    className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#dcd6cd] mb-1">カテゴリ</label>
                    <select
                      value={newWorkForm.category}
                      onChange={(e) =>
                        setNewWorkForm({
                          ...newWorkForm,
                          category: e.target.value as WorkItem['category'],
                        })
                      }
                      className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                    >
                      <option value="モダンBOX">モダンBOX</option>
                      <option value="洋風住宅">洋風住宅</option>
                      <option value="平屋">平屋</option>
                      <option value="ガルバリウム">ガルバリウム</option>
                      <option value="和モダン">和モダン</option>
                      <option value="リフォーム・再生">リフォーム・再生</option>
                      <option value="店舗および工場">店舗および工場</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-[#dcd6cd] mb-1">所在地（※非公開・非表示）</label>
                    <input
                      type="text"
                      placeholder="住所は非公開となります"
                      value={newWorkForm.location || ''}
                      onChange={(e) => setNewWorkForm({ ...newWorkForm, location: e.target.value })}
                      className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-[#dcd6cd] mb-1">竣工時期</label>
                    <input
                      type="text"
                      value={newWorkForm.completionDate || ''}
                      onChange={(e) =>
                        setNewWorkForm({ ...newWorkForm, completionDate: e.target.value })
                      }
                      className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-[#dcd6cd] mb-1">延床面積</label>
                    <input
                      type="text"
                      value={newWorkForm.floorArea || ''}
                      onChange={(e) =>
                        setNewWorkForm({ ...newWorkForm, floorArea: e.target.value })
                      }
                      className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-[#dcd6cd] mb-1">写真画像URL</label>
                  <input
                    type="text"
                    value={newWorkForm.imageUrl || ''}
                    onChange={(e) =>
                      setNewWorkForm({ ...newWorkForm, imageUrl: e.target.value })
                    }
                    className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#dcd6cd] mb-1">説明文</label>
                  <textarea
                    rows={3}
                    value={newWorkForm.description || ''}
                    onChange={(e) =>
                      setNewWorkForm({ ...newWorkForm, description: e.target.value })
                    }
                    className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#dcd6cd] mb-1">外観・仕様（facadeSpec）</label>
                  <input
                    type="text"
                    value={newWorkForm.facadeSpec || ''}
                    onChange={(e) =>
                      setNewWorkForm({ ...newWorkForm, facadeSpec: e.target.value })
                    }
                    className="w-full bg-[#121110] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => setEditingWorkId(null)}
                    className="px-3 py-1.5 rounded bg-[#23211d] text-[#a8a196] text-xs"
                  >
                    キャンセル
                  </button>
                  <button
                    onClick={() => {
                      if (!newWorkForm.title) return alert('タイトルを入力してください');
                      if (editingWorkId === 'new') {
                        addWork(newWorkForm as WorkItem);
                      } else {
                        updateWork(newWorkForm as WorkItem);
                      }
                      setEditingWorkId(null);
                    }}
                    className="px-4 py-1.5 rounded bg-[#b38d4f] text-[#121110] font-bold text-xs"
                  >
                    保存する
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ==================== SERVICES TAB ==================== */}
        {activeEditorTab === 'services' && (
          <div className="space-y-6">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              営業サービスラインナップ編集
            </h4>

            {data.services.map((srv, sIdx) => (
              <div key={srv.id} className="p-4 bg-[#121110] border border-[#2e2a25] rounded space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-[#b38d4f]">
                    {srv.num}. {srv.title}
                  </span>
                </div>

                <div>
                  <label className="block text-xs text-[#8a8377] mb-1">タイトル</label>
                  <input
                    type="text"
                    value={srv.title}
                    onChange={(e) => {
                      const updated = [...data.services];
                      updated[sIdx].title = e.target.value;
                      updateServices(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#8a8377] mb-1">サブタイトル（要約）</label>
                  <input
                    type="text"
                    value={srv.subtitle}
                    onChange={(e) => {
                      const updated = [...data.services];
                      updated[sIdx].subtitle = e.target.value;
                      updateServices(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#8a8377] mb-1">詳細説明</label>
                  <textarea
                    rows={2}
                    value={srv.description}
                    onChange={(e) => {
                      const updated = [...data.services];
                      updated[sIdx].description = e.target.value;
                      updateServices(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#8a8377] mb-1">おすすめ対象者</label>
                  <input
                    type="text"
                    value={srv.targetPersona}
                    onChange={(e) => {
                      const updated = [...data.services];
                      updated[sIdx].targetPersona = e.target.value;
                      updateServices(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-2 text-[#f5f2eb]"
                  />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ==================== LOCAL TAB ==================== */}
        {activeEditorTab === 'local' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              地域密着・こだわり設定
            </h4>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">バッジ文言</label>
              <input
                type="text"
                value={data.localFocus.badge}
                onChange={(e) => updateLocalFocus({ badge: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">見出しタイトル</label>
              <input
                type="text"
                value={data.localFocus.title}
                onChange={(e) => updateLocalFocus({ title: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">リード文</label>
              <textarea
                rows={2}
                value={data.localFocus.subtitle}
                onChange={(e) => updateLocalFocus({ subtitle: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div className="pt-2">
              <span className="text-xs font-bold text-[#a8a196] block mb-2">地域密着の3つのこだわり・強み</span>
              <div className="space-y-3">
                {data.localFocus.strengths.map((st, idx) => (
                  <div key={idx} className="p-3 bg-[#121110] border border-[#2e2a25] rounded space-y-2">
                    <div className="grid grid-cols-3 gap-2">
                      <input
                        type="text"
                        value={st.title}
                        placeholder="強みのタイトル"
                        onChange={(e) => {
                          const updated = [...data.localFocus.strengths];
                          updated[idx].title = e.target.value;
                          updateLocalFocus({ strengths: updated });
                        }}
                        className="col-span-2 bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb]"
                      />
                      <input
                        type="text"
                        value={st.tag}
                        placeholder="タグ"
                        onChange={(e) => {
                          const updated = [...data.localFocus.strengths];
                          updated[idx].tag = e.target.value;
                          updateLocalFocus({ strengths: updated });
                        }}
                        className="bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#b38d4f]"
                      />
                    </div>
                    <textarea
                      rows={2}
                      value={st.description}
                      placeholder="詳細説明"
                      onChange={(e) => {
                        const updated = [...data.localFocus.strengths];
                        updated[idx].description = e.target.value;
                        updateLocalFocus({ strengths: updated });
                      }}
                      className="w-full bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#a8a196]"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ==================== ONREI TAB ==================== */}
        {activeEditorTab === 'onrei' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
                オンレイ全館空調システム 設定
              </h4>
              <span className="text-[10px] text-[#8a8377]">
                株式会社オンレイ導入店舗設定
              </span>
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">導入店舗認定バッジ</label>
              <input
                type="text"
                value={data.onreiSystem.partnerBadge}
                onChange={(e) => updateOnreiSystem({ partnerBadge: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">メインキャッチコピー</label>
              <input
                type="text"
                value={data.onreiSystem.mainTitle}
                onChange={(e) => updateOnreiSystem({ mainTitle: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">サブタイトル（導入店舗説明）</label>
              <input
                type="text"
                value={data.onreiSystem.subTitle}
                onChange={(e) => updateOnreiSystem({ subTitle: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">リード文</label>
              <textarea
                rows={3}
                value={data.onreiSystem.leadParagraph}
                onChange={(e) => updateOnreiSystem({ leadParagraph: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#dcd6cd]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">株式会社オンレイ 企業・システム説明</label>
              <textarea
                rows={3}
                value={data.onreiSystem.companyIntro}
                onChange={(e) => updateOnreiSystem({ companyIntro: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#dcd6cd]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">オンレイ公式URL</label>
              <input
                type="text"
                value={data.onreiSystem.officialUrl}
                onChange={(e) => updateOnreiSystem({ officialUrl: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#b38d4f] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">メイン写真URL（引用元：onrei.jp）</label>
              <input
                type="text"
                value={data.onreiSystem.heroImage || ''}
                onChange={(e) => updateOnreiSystem({ heroImage: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#f5f2eb] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">写真引用クレジット・注記</label>
              <textarea
                rows={2}
                value={data.onreiSystem.citationNotice || ''}
                onChange={(e) => updateOnreiSystem({ citationNotice: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#dcd6cd]"
              />
            </div>

            {/* Gallery items editor */}
            <div className="pt-2">
              <span className="text-xs font-bold text-[#b38d4f] block mb-2">空間実例ギャラリー（onrei.jp引用写真）</span>
              <div className="space-y-3">
                {data.onreiSystem.gallery?.map((item, gIdx) => (
                  <div key={item.id} className="p-3 bg-[#181715] border border-[#2e2a25] rounded space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-[#b38d4f] font-mono">実例 {gIdx + 1}</span>
                      <input
                        type="text"
                        value={item.tag}
                        placeholder="タグ"
                        onChange={(e) => {
                          const updated = [...(data.onreiSystem.gallery || [])];
                          updated[gIdx].tag = e.target.value;
                          updateOnreiSystem({ gallery: updated });
                        }}
                        className="bg-[#221f1a] border border-[#38342f] rounded px-2 py-0.5 text-[10px] text-[#f5f2eb]"
                      />
                    </div>
                    <input
                      type="text"
                      value={item.title}
                      placeholder="タイトル"
                      onChange={(e) => {
                        const updated = [...(data.onreiSystem.gallery || [])];
                        updated[gIdx].title = e.target.value;
                        updateOnreiSystem({ gallery: updated });
                      }}
                      className="w-full bg-[#221f1a] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb]"
                    />
                    <input
                      type="text"
                      value={item.imageUrl}
                      placeholder="画像URL"
                      onChange={(e) => {
                        const updated = [...(data.onreiSystem.gallery || [])];
                        updated[gIdx].imageUrl = e.target.value;
                        updateOnreiSystem({ gallery: updated });
                      }}
                      className="w-full bg-[#221f1a] border border-[#38342f] rounded p-1.5 text-xs text-[#a8a196] font-mono"
                    />
                    <textarea
                      rows={2}
                      value={item.caption}
                      placeholder="キャプション・説明"
                      onChange={(e) => {
                        const updated = [...(data.onreiSystem.gallery || [])];
                        updated[gIdx].caption = e.target.value;
                        updateOnreiSystem({ gallery: updated });
                      }}
                      className="w-full bg-[#221f1a] border border-[#38342f] rounded p-1.5 text-xs text-[#a8a196]"
                    />
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">自社大工による高精度施工のこだわり</label>
              <textarea
                rows={3}
                value={data.onreiSystem.craftsmanshipNote}
                onChange={(e) => updateOnreiSystem({ craftsmanshipNote: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#dcd6cd]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">長期保証・メンテナンス説明</label>
              <textarea
                rows={2}
                value={data.onreiSystem.warrantyInfo}
                onChange={(e) => updateOnreiSystem({ warrantyInfo: e.target.value })}
                className="w-full bg-[#1e1c18] border border-[#38342f] rounded p-2 text-xs text-[#dcd6cd]"
              />
            </div>
          </div>
        )}

        {/* ==================== AEO/SEO TAB ==================== */}
        {activeEditorTab === 'aeoSeo' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              AI・SEO/AEO検索エンジン最適化設定
            </h4>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">セクション見出し</label>
              <input
                type="text"
                value={data.aeoSeo.title}
                onChange={(e) => updateAeoSeo({ title: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">説明文</label>
              <textarea
                rows={2}
                value={data.aeoSeo.subtitle}
                onChange={(e) => updateAeoSeo({ subtitle: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div className="pt-2">
              <span className="text-xs font-bold text-[#a8a196] block mb-2">対象キーワード一覧</span>
              <div className="space-y-3">
                {data.aeoSeo.keywords.map((kw, idx) => (
                  <div key={kw.id} className="p-3 bg-[#121110] border border-[#2e2a25] rounded space-y-2">
                    <div className="grid grid-cols-2 gap-2">
                      <input
                        type="text"
                        value={kw.keyword}
                        onChange={(e) => {
                          const updated = [...data.aeoSeo.keywords];
                          updated[idx].keyword = e.target.value;
                          updateAeoSeo({ keywords: updated });
                        }}
                        className="bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb]"
                      />
                      <input
                        type="text"
                        value={kw.volumeInfo}
                        onChange={(e) => {
                          const updated = [...data.aeoSeo.keywords];
                          updated[idx].volumeInfo = e.target.value;
                          updateAeoSeo({ keywords: updated });
                        }}
                        className="bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb]"
                      />
                    </div>
                    <textarea
                      rows={2}
                      value={kw.aeoSnippet}
                      onChange={(e) => {
                        const updated = [...data.aeoSeo.keywords];
                        updated[idx].aeoSnippet = e.target.value;
                        updateAeoSeo({ keywords: updated });
                      }}
                      className="w-full bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb]"
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ==================== COMPANY TAB ==================== */}
        {activeEditorTab === 'company' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              会社概要・代表挨拶編集
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">商号（会社名）</label>
                <input
                  type="text"
                  value={data.company.name}
                  onChange={(e) => updateCompany({ name: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">代表者役職</label>
                <input
                  type="text"
                  value={data.company.representativeTitle || ''}
                  onChange={(e) => updateCompany({ representativeTitle: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">代表者氏名</label>
                <input
                  type="text"
                  value={data.company.representativeName}
                  onChange={(e) => updateCompany({ representativeName: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">電話番号</label>
                <input
                  type="text"
                  value={data.company.phone}
                  onChange={(e) => updateCompany({ phone: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">メールアドレス</label>
                <input
                  type="text"
                  value={data.company.email}
                  onChange={(e) => updateCompany({ email: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">郵便番号</label>
                <input
                  type="text"
                  value={data.company.postalCode}
                  onChange={(e) => updateCompany({ postalCode: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs text-[#dcd6cd] mb-1">本社住所</label>
                <input
                  type="text"
                  value={data.company.address}
                  onChange={(e) => updateCompany({ address: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">営業時間</label>
                <input
                  type="text"
                  value={data.company.openingHours}
                  onChange={(e) => updateCompany({ openingHours: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#dcd6cd] mb-1">定休日</label>
                <input
                  type="text"
                  value={data.company.holidays}
                  onChange={(e) => updateCompany({ holidays: e.target.value })}
                  className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================== FAQ TAB ==================== */}
        {activeEditorTab === 'faq' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
                よくある質問 (FAQ) 編集
              </h4>
              <button
                onClick={() => {
                  const newItem = {
                    id: `faq-${Date.now()}`,
                    question: '新しい質問を入力してください',
                    answer: '質問に対する回答を入力してください。',
                    category: '一般',
                  };
                  updateFaq([...data.faq, newItem]);
                }}
                className="flex items-center gap-1 px-3 py-1.5 rounded bg-[#b38d4f] text-[#121110] font-bold text-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>質問を追加</span>
              </button>
            </div>

            <div className="space-y-3">
              {data.faq.map((item, idx) => (
                <div key={item.id} className="p-3 bg-[#121110] border border-[#2e2a25] rounded space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <input
                      type="text"
                      placeholder="カテゴリ"
                      value={item.category || ''}
                      onChange={(e) => {
                        const updated = [...data.faq];
                        updated[idx].category = e.target.value;
                        updateFaq(updated);
                      }}
                      className="bg-[#181715] border border-[#38342f] rounded p-1 text-xs text-[#b38d4f] w-28"
                    />
                    <button
                      onClick={() => {
                        updateFaq(data.faq.filter((f) => f.id !== item.id));
                      }}
                      className="text-rose-400 hover:text-rose-300 p-1"
                      title="削除"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={item.question}
                    onChange={(e) => {
                      const updated = [...data.faq];
                      updated[idx].question = e.target.value;
                      updateFaq(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#f5f2eb] font-semibold"
                  />
                  <textarea
                    rows={2}
                    value={item.answer}
                    onChange={(e) => {
                      const updated = [...data.faq];
                      updated[idx].answer = e.target.value;
                      updateFaq(updated);
                    }}
                    className="w-full bg-[#181715] border border-[#38342f] rounded p-1.5 text-xs text-[#a8a196]"
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== CONTACT TAB ==================== */}
        {activeEditorTab === 'contact' && (
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase">
              お問い合わせフォーム・メッセージ設定
            </h4>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">セクションタイトル</label>
              <input
                type="text"
                value={data.contact.title}
                onChange={(e) => updateContact({ title: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">説明サブタイトル</label>
              <textarea
                rows={2}
                value={data.contact.subtitle}
                onChange={(e) => updateContact({ subtitle: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">電話案内文</label>
              <input
                type="text"
                value={data.contact.phoneLead}
                onChange={(e) => updateContact({ phoneLead: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>

            <div>
              <label className="block text-xs text-[#dcd6cd] mb-1">送信完了時メッセージ</label>
              <textarea
                rows={2}
                value={data.contact.successMessage}
                onChange={(e) => updateContact({ successMessage: e.target.value })}
                className="w-full bg-[#121110] border border-[#38342f] rounded p-2.5 text-[#f5f2eb]"
              />
            </div>
          </div>
        )}
      </div>

      {/* Footer Controls */}
      <div className="p-4 bg-[#1a1815] border-t border-[#2e2a25] flex items-center justify-between shrink-0">
        <button
          onClick={resetToDefaults}
          className="flex items-center gap-1.5 px-3 py-2 rounded bg-[#23211d] hover:bg-rose-950/40 text-rose-300 border border-[#38342f] hover:border-rose-800 text-xs transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>初期値に戻す</span>
        </button>

        <button
          onClick={() => setIsEditorDrawerOpen(false)}
          className="flex items-center gap-1.5 px-5 py-2 rounded bg-[#b38d4f] hover:bg-[#c59b57] text-[#121110] font-bold text-xs tracking-wider transition-colors cursor-pointer shadow-md"
        >
          <CheckCircle className="w-4 h-4" />
          <span>編集を完了して閉じる</span>
        </button>
      </div>
    </aside>
  );
};
