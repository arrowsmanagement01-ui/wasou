import React from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Building, MapPin, Phone, Mail, Clock, Calendar, ShieldCheck } from 'lucide-react';

export const CompanyProfile: React.FC = () => {
  const { data } = useSiteData();
  const { company } = data;

  return (
    <EditableWrapper tab="company" label="会社概要・代表挨拶" id="company">
      <section className="py-20 lg:py-28 bg-[#121110] relative border-b border-[#2a2723]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2">
              ABOUT US & GREETING
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              <span className="inline-block">会社概要・代表挨拶</span>
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#a8a196] [text-wrap:balance]">
              <span className="inline-block">伝統の技と真心を胸に、</span>
              <span className="inline-block">富山・魚津の町に寄り添い続ける工務店です。</span>
            </p>
          </div>

          {/* CEO Greeting Card */}
          <div className="bg-[#181715] border border-[#2e2a25] rounded-sm p-6 sm:p-10 mb-16 shadow-xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-48 h-48 koshi-pattern opacity-15 pointer-events-none"></div>

            <div className="max-w-3xl mx-auto">
              <span className="text-xs text-[#b38d4f] font-serif-jp tracking-widest block mb-2">
                MESSAGE FROM CEO
              </span>
              <h3 className="font-serif-jp text-xl sm:text-2xl font-bold text-[#f5f2eb] mb-6 leading-snug [text-wrap:balance]">
                <span className="inline-block">「和の心を、現代の暮らしに創る。」</span>
                <br className="hidden sm:inline" />
                <span className="inline-block mt-1 sm:mt-0">それが社名『和創』に込めた想いです。</span>
              </h3>

              <div className="space-y-4 text-xs sm:text-sm text-[#dcd6cd] leading-relaxed mb-8 [text-wrap:pretty]">
                <p>
                  <span className="inline-block">洗練されたモダンBOX、</span>
                  <span className="inline-block">温もりあふれる洋風住宅、</span>
                  <span className="inline-block">開放感ある平屋、</span>
                  <span className="inline-block">そして伝統の美を宿す和モダン。</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block mt-1 sm:mt-0">私たちは、工業化された画一的な規格住宅では味わえない、</span>
                  <span className="inline-block">お客様一人ひとりの理想に寄り添う自由設計と匠の手仕事をお届けします。</span>
                </p>
                <p>
                  <span className="inline-block">新築の夢はもちろん、</span>
                  <span className="inline-block">小さな建具ひとつの修繕まで、</span>
                  <span className="inline-block">魚津の皆様の生涯のパートナーとして尽力してまいります。</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block mt-1 sm:mt-0">どんな些細なことでも、</span>
                  <span className="inline-block">どうぞ安心してお声がけください。</span>
                </p>
              </div>

              <div className="flex items-center justify-end gap-4 pt-4 border-t border-[#262420]">
                <div className="text-right">
                  <span className="text-xs text-[#8a8377] block">
                    {company.representativeTitle}
                  </span>
                  <span className="font-serif-jp text-base sm:text-lg font-bold text-[#f5f2eb]">
                    {company.representativeName}
                  </span>
                </div>
                {/* Traditional Vermilion Japanese Seal Accent */}
                <div className="w-10 h-10 rounded border-2 border-[#b93a32] flex items-center justify-center p-1 text-[#b93a32] font-serif-jp font-bold text-xs select-none shadow-sm">
                  和創
                </div>
              </div>
            </div>
          </div>

          {/* Company Table & Map Container */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Table */}
            <div className="lg:col-span-7 bg-[#161513] border border-[#2e2a25] rounded-sm overflow-hidden shadow-lg">
              <div className="p-4 sm:p-5 bg-[#1b1916] border-b border-[#2e2a25] flex items-center gap-2">
                <Building className="w-4 h-4 text-[#b38d4f]" />
                <h4 className="font-serif-jp text-sm sm:text-base font-bold text-[#f5f2eb]">
                  企業情報詳細
                </h4>
              </div>

              <div className="divide-y divide-[#23201c] text-xs sm:text-sm">
                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">商号</span>
                  <span className="col-span-2 sm:col-span-3 text-[#f5f2eb] font-bold">
                    {company.name} ({company.legalName})
                  </span>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">代表者</span>
                  <span className="col-span-2 sm:col-span-3 text-[#f5f2eb]">
                    {company.representativeTitle} {company.representativeName}
                  </span>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">創業・設立</span>
                  <span className="col-span-2 sm:col-span-3 text-[#f5f2eb]">
                    {company.foundedDate}
                  </span>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">電話番号</span>
                  <div className="col-span-2 sm:col-span-3 text-[#f5f2eb] font-mono">
                    <a href={`tel:${company.phone}`} className="text-[#b38d4f] hover:underline">
                      {company.phone}
                    </a>
                  </div>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">メールアドレス</span>
                  <div className="col-span-2 sm:col-span-3 text-[#f5f2eb] font-mono">
                    <a href={`mailto:${company.email}`} className="text-[#b38d4f] hover:underline">
                      {company.email}
                    </a>
                  </div>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">業務内容</span>
                  <div className="col-span-2 sm:col-span-3 text-[#dcd6cd] space-y-1">
                    <p>・注文建築（自由設計・モダンBOX・洋風・平屋・和モダンの設計施工）</p>
                    <p>・リフォーム（水まわり刷新・内窓断熱・外装改修）</p>
                    <p>・リノベーション（古民家再生・耐震改修・フルリノベ）</p>
                    <p>・店舗および工場（商業店舗・飲食店・工場・倉庫設計施工）</p>
                    <p>・修繕（建具調整・雨漏り修繕・外壁瓦点検補修）</p>
                  </div>
                </div>

                <div className="p-4 sm:p-5 grid grid-cols-3 sm:grid-cols-4 gap-2">
                  <span className="text-[#8a8377] font-medium">営業時間・定休日</span>
                  <div className="col-span-2 sm:col-span-3 text-[#f5f2eb]">
                    <p>{company.openingHours}</p>
                    <p className="text-xs text-[#a8a196] mt-0.5">{company.holidays}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Regional Coverage Card */}
            <div className="lg:col-span-5 flex flex-col gap-4">
              <div className="bg-[#161513] border border-[#2e2a25] rounded-sm p-5 shadow-lg">
                <div className="flex items-center gap-2 mb-3">
                  <Building className="w-4 h-4 text-[#b38d4f]" />
                  <h4 className="font-serif-jp text-sm sm:text-base font-bold text-[#f5f2eb]">
                    施工対応エリア・ご相談体制
                  </h4>
                </div>
                <p className="text-xs sm:text-sm text-[#dcd6cd] mb-4">
                  富山県魚津市を拠点に、富山県全域および近隣北陸エリアに対応。<br />
                  専任棟梁が責任施工でお応えいたします。
                </p>

                <div className="w-full rounded bg-[#1f1d19] border border-[#2e2a25] p-5 text-center">
                  <span className="font-serif-jp font-bold text-sm text-[#f5f2eb] block mb-2">
                    主な対応エリア
                  </span>
                  <p className="text-xs text-[#a8a196] leading-relaxed">
                    魚津市・黒部市・滑川市・富山市・入善町・朝日町・上市町・立山町・射水市・高岡市ほか
                  </p>
                  <div className="mt-4 pt-3 border-t border-[#2a2723] text-xs text-[#b38d4f]">
                    ※周辺地域のお客様もお気軽にご相談ください
                  </div>
                </div>
              </div>

              {/* Security & License Badges */}
              <div className="bg-[#181715] border border-[#282622] rounded-sm p-4 text-xs text-[#8a8377] space-y-2">
                <div className="flex items-center gap-2 text-[#dcd6cd]">
                  <ShieldCheck className="w-4 h-4 text-[#b38d4f]" />
                  <span className="font-medium">住宅瑕疵担保責任保険 加入事業者</span>
                </div>
                <p className="pl-6">
                  全棟に厳格な構造検査および瑕疵保証、定期点検を実施。一生涯安心して住まいを委ねていただけます。
                </p>
              </div>

              {/* ONREI Air Conditioning System Partner Badge */}
              <div className="bg-[#181715] border border-[#3d362c] rounded-sm p-4 text-xs text-[#8a8377] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#f5f2eb]">
                    <ShieldCheck className="w-4 h-4 text-[#b38d4f]" />
                    <span className="font-semibold text-[#b38d4f]">株式会社オンレイ システム導入認定店</span>
                  </div>
                  <a
                    href="https://onrei.jp/?shem=aimgspe%2C&doing_wp_cron=1792054286.1689798831939697265625"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-[#b38d4f] hover:underline"
                  >
                    公式URL ↗
                  </a>
                </div>
                <p className="pl-6 text-[#a8a196]">
                  次世代全館空調「CLEnAIR（クリネア）」・第一種熱交換換気「PROnAIR」正規施工パートナー。富山の気候に合わせた高断熱×空気質デザインをご提供。
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
