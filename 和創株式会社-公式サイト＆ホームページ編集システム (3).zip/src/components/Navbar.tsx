import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { Phone, Menu, X, ChevronRight } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { data } = useSiteData();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { label: 'コンセプト', href: '#concept' },
    { label: '施工イメージ', href: '#works' },
    { label: 'サービス', href: '#services' },
    { label: 'オンレイ全館空調', href: '#onrei' },
    { label: '地域密着', href: '#local' },
    { label: 'AI・SEO設計', href: '#ai-seo' },
    { label: '会社概要', href: '#company' },
    { label: 'FAQ', href: '#faq' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-[49px] z-40 w-full bg-[#141311]/90 backdrop-blur-md border-b border-[#2a2622]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo and Brand */}
        <a
          href="#"
          className="flex items-center gap-3.5 group cursor-pointer"
          onClick={(e) => {
            e.preventDefault();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        >
          <div className="w-11 h-11 rounded-full bg-[#1f1d19] border border-[#b38d4f]/50 p-1 flex items-center justify-center transition-transform group-hover:scale-105 shadow-inner">
            <img
              src="/wasou-logo.svg"
              alt={data.company.name}
              className="w-full h-full object-contain invert-[0.9] sepia-[0.3]"
            />
          </div>
          <div className="flex flex-col">
            <span className="font-serif-jp text-lg sm:text-xl font-bold tracking-widest text-[#f5f2eb] group-hover:text-[#b38d4f] transition-colors">
              {data.company.name}
            </span>
            <span className="text-[10px] sm:text-xs text-[#a8a196] tracking-wider font-light [text-wrap:balance]">
              <span className="inline-block">富山県魚津市</span>
              <span className="mx-1 opacity-60">·</span>
              <span className="inline-block">自由設計の注文建築とリフォーム</span>
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden xl:flex items-center gap-6 text-sm font-medium text-[#dcd6cd]">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              onClick={(e) => handleNavClick(e, item.href)}
              className="relative py-2 hover:text-[#b38d4f] transition-colors cursor-pointer group"
            >
              <span>{item.label}</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[#b38d4f] transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
        </nav>

        {/* Desktop Contact CTA */}
        <div className="hidden md:flex items-center gap-4">
          <a
            href={`tel:${data.company.phone.replace(/-/g, '')}`}
            className="flex items-center gap-2 text-[#e6dfd5] hover:text-[#b38d4f] transition-colors py-1.5 px-3 rounded-lg border border-transparent hover:border-[#38342f]"
          >
            <div className="w-7 h-7 rounded-full bg-[#b38d4f]/15 flex items-center justify-center text-[#b38d4f]">
              <Phone className="w-3.5 h-3.5" />
            </div>
            <div className="flex flex-col text-left">
              <span className="text-[10px] text-[#8a8377] leading-none">お電話でのご相談</span>
              <span className="text-sm font-bold tracking-wider">{data.company.phone}</span>
            </div>
          </a>

          <a
            href="#contact"
            onClick={(e) => handleNavClick(e, '#contact')}
            className="relative px-5 py-2.5 rounded-sm bg-gradient-to-r from-[#b38d4f] to-[#8f6f3b] hover:from-[#c59b57] hover:to-[#9f7d43] text-[#121110] font-bold text-xs sm:text-sm tracking-wider shadow-md hover:shadow-lg transition-all duration-200 cursor-pointer flex items-center gap-1.5 group"
          >
            <span>無料相談・お見積り</span>
            <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </a>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex items-center gap-2 xl:hidden">
          <a
            href={`tel:${data.company.phone.replace(/-/g, '')}`}
            className="p-2 rounded-lg bg-[#23211d] text-[#b38d4f] border border-[#38342f] md:hidden"
            title="電話をかける"
          >
            <Phone className="w-4 h-4" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2.5 rounded-lg bg-[#23211d] border border-[#38342f] text-[#f5f2eb] hover:text-[#b38d4f] transition-colors cursor-pointer"
            aria-label="メニューを開く"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#161513] border-b border-[#2e2b27] px-6 py-6 animate-fadeIn">
          <nav className="flex flex-col gap-3">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className="flex items-center justify-between py-2.5 text-base border-b border-[#262420] text-[#e6dfd5] hover:text-[#b38d4f] transition-colors"
              >
                <span>{item.label}</span>
                <ChevronRight className="w-4 h-4 text-[#8a8377]" />
              </a>
            ))}
            <div className="pt-4 flex flex-col gap-3">
              <a
                href={`tel:${data.company.phone.replace(/-/g, '')}`}
                className="flex items-center justify-center gap-2 py-3 rounded-md bg-[#23211d] border border-[#38342f] text-[#f5f2eb]"
              >
                <Phone className="w-4 h-4 text-[#b38d4f]" />
                <span className="font-bold">{data.company.phone}</span>
                <span className="text-xs text-[#a8a196]">（{data.company.openingHours}）</span>
              </a>
              <a
                href="#contact"
                onClick={(e) => handleNavClick(e, '#contact')}
                className="flex items-center justify-center gap-2 py-3 rounded-md bg-[#b38d4f] text-[#121110] font-bold shadow-md"
              >
                <span>無料相談・お見積りフォームへ</span>
                <ChevronRight className="w-4 h-4" />
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};
