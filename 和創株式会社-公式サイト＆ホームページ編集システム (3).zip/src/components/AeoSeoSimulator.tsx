import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Sparkles, Bot, Search, Code, CheckCircle, RefreshCw } from 'lucide-react';

export const AeoSeoSimulator: React.FC = () => {
  const { data } = useSiteData();
  const { aeoSeo } = data;

  const [selectedKwId, setSelectedKwId] = useState<string>(
    aeoSeo.keywords[0]?.id || ''
  );
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [showJsonLd, setShowJsonLd] = useState<boolean>(false);

  const currentKw =
    aeoSeo.keywords.find((k) => k.id === selectedKwId) || aeoSeo.keywords[0];

  const handleSimulate = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setIsSimulating(false);
    }, 600);
  };

  // Generate real dynamic JSON-LD representation for the site
  const jsonLdData = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'HomeAndConstructionBusiness',
        '@id': 'https://wasou1204.com/#organization',
        name: data.company.name,
        legalName: data.company.legalName,
        founder: {
          '@type': 'Person',
          name: data.company.representativeName,
          jobTitle: data.company.representativeTitle,
        },
        foundingDate: '2025-12',
        telephone: data.company.phone,
        email: data.company.email,
        address: {
          '@type': 'PostalAddress',
          streetAddress: data.company.address.replace('富山県魚津市', ''),
          addressLocality: '魚津市',
          addressRegion: '富山県',
          postalCode: data.company.postalCode,
          addressCountry: 'JP',
        },
        areaServed: data.company.areaServed.map((city) => ({
          '@type': 'City',
          name: city,
        })),
        priceRange: '¥¥¥',
      },
      {
        '@type': 'FAQPage',
        '@id': 'https://wasou1204.com/#faq',
        mainEntity: data.faq.map((item) => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: {
            '@type': 'Answer',
            text: item.answer,
          },
        })),
      },
    ],
  };

  return (
    <EditableWrapper tab="aeoSeo" label="AI・SEO/AEO設計" id="ai-seo">
      <section className="py-20 lg:py-28 bg-[#161513] relative border-b border-[#2a2723]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#b38d4f]/15 border border-[#b38d4f]/40 text-[#b38d4f] text-xs font-semibold tracking-wider mb-3">
              <Bot className="w-3.5 h-3.5" />
              {aeoSeo.badge}
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              {aeoSeo.title}
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#dcd6cd] max-w-2xl mx-auto leading-relaxed [text-wrap:pretty]">
              {aeoSeo.subtitle}
            </p>
          </div>

          {/* Interactive Simulator Card */}
          <div className="bg-[#1c1a17] border border-[#38342f] rounded-sm p-6 sm:p-10 mb-16 shadow-2xl">
            {/* Top Toolbar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#2e2a25] mb-8">
              <div>
                <span className="text-xs text-[#8a8377] block mb-1">
                  シミュレーションする検索キーワードを選択してください：
                </span>
                <div className="flex flex-wrap gap-2">
                  {aeoSeo.keywords.map((kw) => (
                    <button
                      key={kw.id}
                      onClick={() => {
                        setSelectedKwId(kw.id);
                        handleSimulate();
                      }}
                      className={`px-3.5 py-1.5 rounded-sm text-xs font-medium transition-all cursor-pointer border ${
                        selectedKwId === kw.id
                          ? 'bg-[#b38d4f] text-[#121110] border-[#b38d4f] font-bold'
                          : 'bg-[#23211d] text-[#e6dfd5] border-[#38342f] hover:border-[#b38d4f]/50'
                      }`}
                    >
                      {kw.keyword}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto">
                <button
                  onClick={handleSimulate}
                  disabled={isSimulating}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-[#23211d] hover:bg-[#2b2722] border border-[#38342f] text-xs text-[#dcd6cd] cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 text-[#b38d4f] ${isSimulating ? 'animate-spin' : ''}`} />
                  <span>再生成を実行</span>
                </button>
                <button
                  onClick={() => setShowJsonLd(!showJsonLd)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs border cursor-pointer ${
                    showJsonLd
                      ? 'bg-[#b38d4f] text-[#121110] border-[#b38d4f] font-bold'
                      : 'bg-[#23211d] text-[#dcd6cd] border-[#38342f] hover:border-[#b38d4f]'
                  }`}
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>構造化データ</span>
                </button>
              </div>
            </div>

            {/* Keyword Meta Info Bar */}
            {currentKw && (
              <div className="bg-[#141311] border border-[#2e2a25] rounded p-4 mb-8 flex flex-wrap items-center justify-between gap-4 text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span className="text-[#8a8377]">検索ボリューム:</span>
                  <span className="text-[#f5f2eb] font-semibold">{currentKw.volumeInfo}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[#8a8377]">ターゲット層:</span>
                  <span className="text-[#c5bcad]">{currentKw.targetUser}</span>
                </div>
              </div>
            )}

            {/* Content Display: AEO Snippet or JSON-LD */}
            {showJsonLd ? (
              <div className="bg-[#121110] border border-[#2e2a25] rounded p-4 overflow-x-auto text-xs font-mono text-emerald-400">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#2e2a25] text-[#8a8377]">
                  <span>本番サイトに組み込まれた構造化データ (JSON-LD)</span>
                  <span className="text-[10px] text-[#b38d4f]">Schema.org 準拠</span>
                </div>
                <pre>{JSON.stringify(jsonLdData, null, 2)}</pre>
              </div>
            ) : currentKw ? (
              <div className="space-y-6">
                {/* H1 SEO Title */}
                <div className="bg-[#141311] border border-[#2a2723] rounded p-5">
                  <span className="text-[10px] text-[#b38d4f] font-mono tracking-widest block mb-1">
                    生成されたSEO/AEOタイトル (H1)
                  </span>
                  <h3 className="font-serif-jp text-base sm:text-lg font-bold text-[#f5f2eb]">
                    {currentKw.articleTitle}
                  </h3>
                </div>

                {/* Perplexity / AI Overviews Snippet */}
                <div className="bg-[#181715] border-l-4 border-[#b38d4f] rounded-r p-5 shadow-inner">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-[#b38d4f]" />
                    <span className="text-xs font-bold text-[#b38d4f]">
                      AEO（Perplexity / ChatGPT Search / AI Overviews）引用最適化スニペット
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-[#dcd6cd] leading-relaxed">
                    {currentKw.aeoSnippet}
                  </p>
                </div>

                {/* FAQ Structured Pairs */}
                {currentKw.qas && currentKw.qas.length > 0 && (
                  <div className="bg-[#141311] border border-[#2e2a25] rounded p-5">
                    <span className="text-xs font-bold text-[#a8a196] block mb-3">
                      自動生成されたQ&A（FAQPage構造化データ連携）
                    </span>
                    <div className="space-y-4">
                      {currentKw.qas.map((qa, qIdx) => (
                        <div key={qIdx} className="text-xs space-y-1">
                          <div className="text-[#f5f2eb] font-semibold flex items-center gap-1.5">
                            <span className="text-[#b38d4f] font-bold">Q.</span>
                            <span>{qa.question}</span>
                          </div>
                          <div className="text-[#a8a196] pl-4 leading-relaxed">
                            <span className="text-[#b38d4f] font-bold -ml-4 mr-1.5">A.</span>
                            {qa.answer}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>

          {/* System Architecture Pipeline Steps */}
          <div className="bg-[#1a1815] border border-[#2e2a25] rounded-sm p-6 sm:p-10">
            <h3 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] mb-2 text-center">
              AI検索最適化（AEO）自律運用パイプライン
            </h3>
            <p className="text-xs text-[#a8a196] text-center mb-8">
              日々の検索トレンド・競合動向をクローリングし、E-E-A-Tに準拠した高品質コンテンツを自動生成
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {aeoSeo.pipelineSteps.map((step, idx) => (
                <div
                  key={idx}
                  className="bg-[#141311] border border-[#282622] p-5 rounded-sm flex flex-col justify-between"
                >
                  <div>
                    <span className="font-mono text-[10px] text-[#b38d4f] block mb-1">
                      {step.step}
                    </span>
                    <h4 className="font-serif-jp text-sm font-bold text-[#f5f2eb] mb-2">
                      {step.title}
                    </h4>
                    <p className="text-xs text-[#8a8377] leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-[#23211d] flex items-center justify-between text-[11px] text-[#a8a196]">
                    <span>自動化</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
