import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { WorkItem } from '../types/siteData';
import { MapPin, Calendar, Plus, Edit, Trash2, ArrowUpRight } from 'lucide-react';

export const WorksGallery: React.FC = () => {
  const {
    data,
    setSelectedWorkForModal,
    isEditMode,
    openEditorForSection,
    deleteWork,
  } = useSiteData();

  const [activeCategory, setActiveCategory] = useState<string>('すべて');

  const categories = [
    'すべて',
    'モダンBOX',
    '洋風住宅',
    '平屋',
    'ガルバリウム',
    '和モダン',
    'リフォーム・再生',
    '店舗および工場',
  ];

  const filteredWorks =
    activeCategory === 'すべて'
      ? data.works
      : data.works.filter((w) => w.category === activeCategory);

  return (
    <EditableWrapper tab="works" label="施工イメージ" id="works">
      <section className="py-20 lg:py-28 bg-[#121110] relative border-b border-[#2a2723]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
            <div>
              <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2">
                WORKS & ARCHITECTURE
              </span>
              <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide [text-wrap:balance]">
                施工イメージ
              </h2>
              <p className="text-xs sm:text-sm text-[#a8a196] mt-2 [text-wrap:pretty]">
                <span className="inline-block">モダンBOX・洋風・平屋・ガルバリウム鋼板・和モダンまで、</span>
                <span className="inline-block">理想を形にした自由設計の建築イメージ</span>
              </p>
            </div>

            {/* In Edit Mode: Add work button */}
            {isEditMode && (
              <button
                onClick={() => openEditorForSection('works')}
                className="self-start md:self-auto flex items-center gap-1.5 px-4 py-2 bg-[#b38d4f] hover:bg-[#c59b57] text-[#121110] font-bold text-xs sm:text-sm rounded-sm transition-colors cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>新しい施工イメージを追加</span>
              </button>
            )}
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-sm text-xs sm:text-sm font-medium tracking-wider whitespace-nowrap transition-all cursor-pointer border ${
                  activeCategory === cat
                    ? 'bg-[#b38d4f] text-[#121110] border-[#b38d4f] font-bold shadow-md'
                    : 'bg-[#1a1815] text-[#a8a196] border-[#38342f] hover:text-[#f5f2eb] hover:border-[#b38d4f]/50'
                }`}
              >
                {cat}
                <span className="ml-1.5 text-[11px] opacity-70">
                  ({cat === 'すべて' ? data.works.length : data.works.filter((w) => w.category === cat).length})
                </span>
              </button>
            ))}
          </div>

          {/* Works Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredWorks.map((work) => (
              <div
                key={work.id}
                className="bg-[#181715] border border-[#2e2a25] hover:border-[#b38d4f]/60 rounded-sm overflow-hidden flex flex-col group transition-all duration-300 shadow-lg hover:shadow-2xl"
              >
                {/* Image Container */}
                <div
                  className="relative h-56 sm:h-64 overflow-hidden bg-black cursor-pointer"
                  onClick={() => setSelectedWorkForModal(work)}
                >
                  <img
                    src={work.imageUrl || '/assets/hero.jpg'}
                    alt={work.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover filter brightness-[0.9] group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#181715] via-transparent to-transparent opacity-80"></div>

                  {/* Top Category Badge */}
                  <div className="absolute top-3 left-3 flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-sm bg-[#141311]/90 text-[#b38d4f] border border-[#b38d4f]/50 text-xs font-bold tracking-wider backdrop-blur-sm">
                      {work.category}
                    </span>
                  </div>

                  {/* Prominent Image Annotation Badge */}
                  <div className="absolute top-3 right-3 pointer-events-none select-none">
                    <span className="px-2 py-0.5 rounded bg-[#121110]/90 border border-[#3e3932] text-[10px] text-[#e6dfd5] font-medium tracking-wider backdrop-blur-sm shadow-sm">
                      ※イメージ写真
                    </span>
                  </div>

                  {/* Open Detail Indicator */}
                  <div className="absolute bottom-3 right-3 w-8 h-8 rounded-full bg-[#1e1c19]/90 border border-[#b38d4f]/60 flex items-center justify-center text-[#f5f2eb] group-hover:bg-[#b38d4f] group-hover:text-[#121110] transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Date */}
                    <div className="flex items-center gap-2 text-xs text-[#8a8377] mb-2.5">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-[#b38d4f]" />
                        {work.completionDate}
                      </span>
                    </div>

                    {/* Title */}
                    <h3
                      onClick={() => setSelectedWorkForModal(work)}
                      className="font-serif-jp text-lg font-bold text-[#f5f2eb] leading-snug mb-3 group-hover:text-[#b38d4f] transition-colors cursor-pointer [text-wrap:balance]"
                    >
                      {work.title}
                    </h3>

                    {/* Short Description */}
                    <p className="text-xs sm:text-sm text-[#a8a196] leading-relaxed line-clamp-2 mb-4 [text-wrap:pretty]">
                      {work.description}
                    </p>

                    {/* Key Spec Badge */}
                    {work.facadeSpec && (
                      <div className="bg-[#1f1d19] border border-[#2e2a25] rounded p-2 text-[11px] text-[#c5bcad] line-clamp-1 mb-4">
                        <span className="text-[#b38d4f] font-semibold mr-1">仕様:</span>
                        {work.facadeSpec}
                      </div>
                    )}
                  </div>

                  {/* Bottom Row */}
                  <div className="pt-4 border-t border-[#262420] flex items-center justify-between">
                    <button
                      onClick={() => setSelectedWorkForModal(work)}
                      className="text-xs font-bold text-[#b38d4f] hover:text-[#c59b57] transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <span>詳細スペックを見る</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>

                    {/* Edit mode controls */}
                    {isEditMode && (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => openEditorForSection('works')}
                          className="p-1.5 rounded bg-[#23211d] hover:bg-[#38342f] text-[#b38d4f] transition-colors"
                          title="この事例を編集"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (window.confirm(`「${work.title}」を削除しますか？`)) {
                              deleteWork(work.id);
                            }
                          }}
                          className="p-1.5 rounded bg-[#23211d] hover:bg-rose-950 text-rose-400 transition-colors"
                          title="削除"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
