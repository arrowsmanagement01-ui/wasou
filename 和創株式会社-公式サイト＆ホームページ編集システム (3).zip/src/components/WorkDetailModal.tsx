import React from 'react';
import { WorkItem } from '../types/siteData';
import { X, MapPin, Calendar, Check, ChevronRight, Ruler, Building, ShieldCheck } from 'lucide-react';

interface WorkDetailModalProps {
  work: WorkItem | null;
  onClose: () => void;
  onConsult: (category: string) => void;
}

export const WorkDetailModal: React.FC<WorkDetailModalProps> = ({
  work,
  onClose,
  onConsult,
}) => {
  if (!work) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-work-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-4xl max-h-[90vh] bg-[#181715] border border-[#3e3932] rounded-sm shadow-2xl overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-[#141311]/80 hover:bg-[#b38d4f] text-[#e6dfd5] hover:text-[#121110] border border-[#38342f] transition-colors cursor-pointer"
          aria-label="モーダルを閉じる"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Image */}
        <div className="relative h-64 sm:h-96 w-full overflow-hidden bg-black">
          <img
            src={work.imageUrl || '/assets/hero.jpg'}
            alt={work.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center filter brightness-[0.95]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#181715] via-transparent to-transparent"></div>

          {/* Prominent Image Annotation Badge */}
          <div className="absolute top-4 left-4 z-20 pointer-events-none select-none">
            <span className="px-3 py-1 rounded bg-[#121110]/90 border border-[#3e3932] text-xs text-[#e6dfd5] font-semibold tracking-wider backdrop-blur-sm shadow-md">
              ※イメージ写真
            </span>
          </div>

          <div className="absolute bottom-4 left-4 sm:left-6 flex flex-wrap gap-2">
            <span className="px-3 py-1 rounded-sm bg-[#b38d4f] text-[#121110] font-bold text-xs tracking-wider">
              {work.category}
            </span>
            <span className="px-3 py-1 rounded-sm bg-[#1e1c19]/90 border border-[#3e3932] text-[#a8a196] text-xs flex items-center gap-1">
              <Calendar className="w-3 h-3 text-[#b38d4f]" />
              {work.completionDate}
            </span>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 sm:p-8">
          <h3 id="modal-work-title" className="font-serif-jp text-2xl sm:text-3xl font-bold text-[#f5f2eb] leading-tight mb-4 [text-wrap:balance]">
            {work.title}
          </h3>

          <p className="text-sm sm:text-base text-[#dcd6cd] leading-relaxed mb-8 [text-wrap:pretty]">
            {work.description}
          </p>

          {/* Specification Table */}
          <div className="mb-8 bg-[#1f1d19] border border-[#2e2a25] rounded-sm p-4 sm:p-6">
            <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase mb-4 flex items-center gap-2">
              <Building className="w-4 h-4" />
              建築施工仕様・設計データ
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs sm:text-sm">
              {work.floorArea && (
                <div className="flex items-start gap-2 border-b border-[#2e2a25] pb-2">
                  <span className="text-[#8a8377] w-24 shrink-0 flex items-center gap-1">
                    <Ruler className="w-3 h-3 text-[#b38d4f]" /> 面積:
                  </span>
                  <span className="text-[#f5f2eb] font-medium">{work.floorArea}</span>
                </div>
              )}
              {work.structure && (
                <div className="flex items-start gap-2 border-b border-[#2e2a25] pb-2">
                  <span className="text-[#8a8377] w-24 shrink-0">構造工法:</span>
                  <span className="text-[#f5f2eb] font-medium">{work.structure}</span>
                </div>
              )}
              {work.insulation && (
                <div className="flex items-start gap-2 border-b border-[#2e2a25] pb-2">
                  <span className="text-[#8a8377] w-24 shrink-0 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-[#b38d4f]" /> 断熱性能:
                  </span>
                  <span className="text-[#f5f2eb] font-medium">{work.insulation}</span>
                </div>
              )}
              {work.facadeSpec && (
                <div className="flex items-start gap-2 border-b border-[#2e2a25] pb-2">
                  <span className="text-[#8a8377] w-24 shrink-0">外観・仕様:</span>
                  <span className="text-[#f5f2eb] font-medium">{work.facadeSpec}</span>
                </div>
              )}
            </div>
          </div>

          {/* Highlights */}
          {work.highlights && work.highlights.length > 0 && (
            <div className="mb-8">
              <h4 className="text-xs font-bold text-[#b38d4f] tracking-widest uppercase mb-3">
                施工のこだわり・設計ポイント
              </h4>
              <ul className="space-y-2.5">
                {work.highlights.map((h, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs sm:text-sm text-[#dcd6cd]">
                    <span className="w-4 h-4 rounded-full bg-[#b38d4f]/20 text-[#b38d4f] flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3 h-3" />
                    </span>
                    <span>{h}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Action Button */}
          <div className="pt-4 border-t border-[#2e2a25] flex flex-col sm:flex-row items-center justify-between gap-4">
            <span className="text-xs text-[#8a8377]">
              類似の施工条件や概算ご予算についてお気軽にお問い合わせください。
            </span>
            <button
              onClick={() => {
                onClose();
                onConsult(work.category);
              }}
              className="w-full sm:w-auto px-6 py-3 rounded-sm bg-[#b38d4f] hover:bg-[#c59b57] text-[#121110] font-bold text-xs sm:text-sm tracking-wider transition-colors cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>この施工イメージについて相談・見積依頼</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
