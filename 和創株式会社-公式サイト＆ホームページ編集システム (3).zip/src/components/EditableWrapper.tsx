import React from 'react';
import { useSiteData, EditorTab } from '../context/SiteContext';
import { Edit3 } from 'lucide-react';

interface EditableWrapperProps {
  tab: EditorTab;
  label: string;
  children: React.ReactNode;
  id?: string;
  className?: string;
}

export const EditableWrapper: React.FC<EditableWrapperProps> = ({
  tab,
  label,
  children,
  id,
  className = '',
}) => {
  const { isEditMode, openEditorForSection } = useSiteData();

  return (
    <div
      id={id}
      className={`relative group ${className} ${
        isEditMode ? 'outline-dashed outline-1 outline-[#b38d4f]/40 hover:outline-[#b38d4f] transition-all' : ''
      }`}
    >
      {isEditMode && (
        <button
          onClick={() => openEditorForSection(tab)}
          type="button"
          className="absolute top-4 right-4 z-40 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#1c1a17]/90 hover:bg-[#b38d4f] text-[#f5f2eb] border border-[#b38d4f]/60 shadow-lg text-xs font-medium tracking-wider backdrop-blur-sm transition-all duration-200 cursor-pointer transform hover:scale-105"
          title={`${label}を編集`}
        >
          <Edit3 className="w-3.5 h-3.5 text-[#b38d4f] group-hover:text-white" />
          <span>{label}を編集</span>
        </button>
      )}
      {children}
    </div>
  );
};
