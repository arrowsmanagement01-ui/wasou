import React, { useState } from 'react';
import { useSiteData } from '../context/SiteContext';
import { EditableWrapper } from './EditableWrapper';
import { Phone, Mail, MapPin, ShieldCheck, CheckCircle2, Send, Loader2, ArrowRight } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const { data } = useSiteData();
  const { contact, company } = data;

  const [formData, setFormData] = useState({
    category: '注文建築',
    name: '',
    address: '富山県魚津市',
    phone: '',
    email: '',
    message: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'お名前を入力してください。';
    if (!formData.address.trim()) errs.address = 'ご希望の施工エリア（市区町村）を入力してください。';
    if (!formData.phone.trim()) {
      errs.phone = 'お電話番号を入力してください。';
    } else if (!/^[0-9\-+()]{9,15}$/.test(formData.phone.trim())) {
      errs.phone = '正しい電話番号の形式で入力してください（例: 0765-57-5015）。';
    }
    if (!formData.email.trim()) {
      errs.email = 'メールアドレスを入力してください。';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errs.email = '有効なメールアドレスを入力してください。';
    }
    if (!formData.message.trim()) {
      errs.message = 'ご相談・お問い合わせ内容を入力してください。';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 900);
  };

  return (
    <EditableWrapper tab="contact" label="お問い合わせ・見積フォーム" id="contact">
      <section className="py-20 lg:py-28 bg-[#121110] relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-[#b38d4f] font-serif-jp text-sm tracking-[0.25em] font-medium block mb-2">
              CONTACT & ESTIMATE
            </span>
            <h2 className="font-serif-jp text-2xl sm:text-4xl font-bold text-[#f5f2eb] tracking-wide mb-3 [text-wrap:balance]">
              <span className="inline-block">{contact.title}</span>
            </h2>
            <div className="w-12 h-0.5 bg-[#b38d4f] mx-auto mb-4"></div>
            <p className="text-xs sm:text-sm text-[#dcd6cd] max-w-2xl mx-auto leading-relaxed [text-wrap:pretty]">
              <span className="inline-block">新築・リフォーム・リノベーション・店舗・修繕のご相談。</span>
              <br className="hidden sm:inline" />
              <span className="inline-block">どんな些細なことでも、まずはお気軽にお問い合わせください。</span>
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Left Column: Direct Phone & Promises */}
            <div className="lg:col-span-5 space-y-6">
              {/* Phone Card */}
              <div className="bg-[#181715] border border-[#2e2a25] rounded-sm p-6 sm:p-8 shadow-xl">
                <span className="text-xs text-[#b38d4f] font-bold tracking-widest uppercase block mb-2">
                  TELEPHONE CONTACT
                </span>
                <h3 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] mb-2 [text-wrap:balance]">
                  お電話でのお問い合わせ
                </h3>
                <p className="text-xs text-[#a8a196] mb-6 [text-wrap:pretty]">
                  <span className="inline-block">「少し話を聞いてみたい」</span>
                  <span className="inline-block">「急ぎで見積りがほしい」など、</span>
                  <br className="hidden sm:inline" />
                  <span className="inline-block">お電話でも親身に対応いたします。</span>
                </p>

                <a
                  href={`tel:${company.phone.replace(/-/g, '')}`}
                  className="flex items-center gap-4 p-4 rounded-sm bg-[#23211d] hover:bg-[#b38d4f] group border border-[#38342f] hover:border-[#b38d4f] transition-all"
                >
                  <div className="w-12 h-12 rounded-full bg-[#b38d4f]/20 group-hover:bg-[#121110]/20 flex items-center justify-center text-[#b38d4f] group-hover:text-[#121110] transition-colors">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-xs text-[#8a8377] group-hover:text-[#121110]/80 block">
                      受付時間: {company.openingHours}
                    </span>
                    <span className="font-mono text-xl sm:text-2xl font-bold text-[#f5f2eb] group-hover:text-[#121110] tracking-wider transition-colors">
                      {company.phone}
                    </span>
                  </div>
                </a>
              </div>

              {/* Company Quick Details */}
              <div className="bg-[#161513] border border-[#282622] rounded-sm p-6 space-y-3 text-xs text-[#a8a196]">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-[#b38d4f]" />
                  <span>{company.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#b38d4f]" />
                  <span>施工地域: 富山県魚津市・富山県全域および近隣エリア</span>
                </div>
              </div>

              {/* 3 Promises */}
              <div className="bg-[#1a1815] border border-[#3e3932] rounded-sm p-6 sm:p-7">
                <div className="flex items-center gap-2 mb-4">
                  <ShieldCheck className="w-5 h-5 text-[#b38d4f]" />
                  <h4 className="font-serif-jp text-sm font-bold text-[#f5f2eb]">
                    和創株式会社の3つのお約束
                  </h4>
                </div>
                <ul className="space-y-3">
                  {contact.promises.map((p, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-[#dcd6cd] leading-relaxed [text-wrap:pretty]">
                      <span className="w-4 h-4 rounded-full bg-[#b38d4f]/20 text-[#b38d4f] flex items-center justify-center shrink-0 mt-0.5 text-[10px] font-bold">
                        ✓
                      </span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Right Column: Form */}
            <div className="lg:col-span-7">
              <div className="bg-[#181715] border border-[#38342f] rounded-sm p-6 sm:p-10 shadow-2xl">
                {isSubmitted ? (
                  <div className="text-center py-12 animate-fadeIn">
                    <div className="w-16 h-16 rounded-full bg-emerald-950/60 border border-emerald-600/50 flex items-center justify-center text-emerald-400 mx-auto mb-6">
                      <CheckCircle2 className="w-8 h-8" />
                    </div>
                    <h3 className="font-serif-jp text-xl sm:text-2xl font-bold text-[#f5f2eb] mb-3">
                      お問い合わせありがとうございます
                    </h3>
                    <p className="text-xs sm:text-sm text-[#a8a196] max-w-md mx-auto leading-relaxed mb-8">
                      {contact.successMessage}
                    </p>

                    <div className="bg-[#141311] border border-[#282622] rounded p-5 max-w-md mx-auto text-left text-xs space-y-2 mb-8 text-[#dcd6cd]">
                      <div><span className="text-[#8a8377]">お名前:</span> {formData.name} 様</div>
                      <div><span className="text-[#8a8377]">ご希望エリア:</span> {formData.address}</div>
                      <div><span className="text-[#8a8377]">お電話:</span> {formData.phone}</div>
                      <div><span className="text-[#8a8377]">メール:</span> {formData.email}</div>
                      <div><span className="text-[#8a8377]">ご相談種別:</span> {formData.category}</div>
                    </div>

                    <button
                      onClick={() => {
                        setIsSubmitted(false);
                        setFormData({
                          category: '注文建築',
                          name: '',
                          address: '富山県魚津市',
                          phone: '',
                          email: '',
                          message: '',
                        });
                      }}
                      className="px-6 py-2.5 rounded-sm bg-[#23211d] hover:bg-[#38342f] border border-[#38342f] text-xs text-[#e6dfd5] font-medium transition-colors cursor-pointer"
                    >
                      別のお問い合わせを送る
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} noValidate className="space-y-5">
                    <div>
                      <h3 className="font-serif-jp text-lg sm:text-xl font-bold text-[#f5f2eb] mb-1">
                        ご相談・お見積りフォーム
                      </h3>
                      <p className="text-xs text-[#8a8377]">
                        下記項目をご入力のうえ、「確認して送信する」ボタンを押してください。
                      </p>
                    </div>

                    {/* Consultation Type */}
                    <div>
                      <label htmlFor="consultation-type" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                        ご相談内容の分類 <span className="text-rose-400">*必須</span>
                      </label>
                      <select
                        id="consultation-type"
                        value={formData.category}
                        onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                        className="w-full bg-[#141311] border border-[#38342f] focus:border-[#b38d4f] rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] focus:outline-none transition-colors"
                      >
                        <option value="注文建築">注文建築（和モダン邸宅新築）</option>
                        <option value="リフォーム">リフォーム（断熱・水まわり・建具）</option>
                        <option value="リノベーション">リノベーション（古民家再生・耐震改修）</option>
                        <option value="店舗および工場">店舗および工場（商業施設・事業所）</option>
                        <option value="修繕">修繕・メンテナンス（即日対応・小さな工事）</option>
                        <option value="その他相談">その他相談・概算見積もり・土地探し</option>
                      </select>
                    </div>

                    {/* Name */}
                    <div>
                      <label htmlFor="name-input" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                        お名前 <span className="text-rose-400">*必須</span>
                      </label>
                      <input
                        id="name-input"
                        type="text"
                        placeholder="例: 魚津 太郎"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className={`w-full bg-[#141311] border rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] placeholder-[#666056] focus:outline-none transition-colors ${
                          errors.name ? 'border-rose-500' : 'border-[#38342f] focus:border-[#b38d4f]'
                        }`}
                      />
                      {errors.name && <p className="text-xs text-rose-400 mt-1">{errors.name}</p>}
                    </div>

                    {/* Address / Planning Area */}
                    <div>
                      <label htmlFor="address-input" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                        ご計画地域・市区町村 <span className="text-rose-400">*必須</span>
                      </label>
                      <input
                        id="address-input"
                        type="text"
                        placeholder="例: 富山県魚津市、黒部市、富山市 など"
                        value={formData.address}
                        onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                        className={`w-full bg-[#141311] border rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] placeholder-[#666056] focus:outline-none transition-colors ${
                          errors.address ? 'border-rose-500' : 'border-[#38342f] focus:border-[#b38d4f]'
                        }`}
                      />
                      {errors.address && <p className="text-xs text-rose-400 mt-1">{errors.address}</p>}
                    </div>

                    {/* Phone & Email Row */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="phone-input" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                          電話番号 <span className="text-rose-400">*必須</span>
                        </label>
                        <input
                          id="phone-input"
                          type="tel"
                          placeholder="例: 0765-57-5015"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className={`w-full bg-[#141311] border rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] placeholder-[#666056] focus:outline-none transition-colors ${
                            errors.phone ? 'border-rose-500' : 'border-[#38342f] focus:border-[#b38d4f]'
                          }`}
                        />
                        {errors.phone && <p className="text-xs text-rose-400 mt-1">{errors.phone}</p>}
                      </div>

                      <div>
                        <label htmlFor="email-input" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                          メールアドレス <span className="text-rose-400">*必須</span>
                        </label>
                        <input
                          id="email-input"
                          type="email"
                          placeholder="例: user@example.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className={`w-full bg-[#141311] border rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] placeholder-[#666056] focus:outline-none transition-colors ${
                            errors.email ? 'border-rose-500' : 'border-[#38342f] focus:border-[#b38d4f]'
                          }`}
                        />
                        {errors.email && <p className="text-xs text-rose-400 mt-1">{errors.email}</p>}
                      </div>
                    </div>

                    {/* Message */}
                    <div>
                      <label htmlFor="message-input" className="block text-xs font-semibold text-[#dcd6cd] mb-1.5">
                        お問い合わせ・ご相談内容 <span className="text-rose-400">*必須</span>
                      </label>
                      <textarea
                        id="message-input"
                        rows={4}
                        placeholder="新築のご計画時期、土地の有無、リフォームのご予算や現状の不具合など、ご自由にお書き添えください。"
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className={`w-full bg-[#141311] border rounded-sm px-3.5 py-2.5 text-xs sm:text-sm text-[#f5f2eb] placeholder-[#666056] focus:outline-none transition-colors ${
                          errors.message ? 'border-rose-500' : 'border-[#38342f] focus:border-[#b38d4f]'
                        }`}
                      ></textarea>
                      {errors.message && <p className="text-xs text-rose-400 mt-1">{errors.message}</p>}
                    </div>

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-4 rounded-sm bg-gradient-to-r from-[#b38d4f] via-[#c29853] to-[#8f6f3b] hover:from-[#c59b57] hover:to-[#9f7d43] text-[#121110] font-bold text-sm sm:text-base tracking-wider shadow-lg hover:shadow-xl transition-all duration-200 cursor-pointer flex items-center justify-center gap-2"
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" />
                          <span>送信処理中...</span>
                        </>
                      ) : (
                        <>
                          <span>上記の内容で無料相談・お見積りを送信する</span>
                          <Send className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </EditableWrapper>
  );
};
